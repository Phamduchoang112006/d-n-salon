<?php
// login.php - Trang Đăng Nhập Khách Hàng, Stylist & Quản Trị Viên (PHP)
require_once __DIR__ . '/db.php';
$db = get_db();

$errorMsg = '';
$successMsg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mode = $_POST['mode'] ?? 'customer_login';

    if ($mode === 'customer_login') {
        $phone = trim($_POST['phone'] ?? '');
        $password = trim($_POST['password'] ?? '');

        if (empty($phone) || empty($password)) {
            $errorMsg = 'Vui lòng điền Số điện thoại và Mật khẩu!';
        } else {
            $_SESSION['user'] = [
                'name' => "Khách Hàng (" . substr($phone, -4) . ")",
                'phone' => $phone,
                'email' => '',
                'role' => 'customer'
            ];
            header('Location: index.php');
            exit;
        }
    } elseif ($mode === 'stylist_login') {
        $stylist_name = trim($_POST['stylist_name'] ?? '');
        if (!empty($stylist_name)) {
            $stmt = get_pdo()->prepare("SELECT * FROM stylists WHERE name = ? LIMIT 1");
            $stmt->execute([$stylist_name]);
            $matched = $stmt->fetch();
            if ($matched) {
                $_SESSION['stylist'] = [
                    'id' => $matched['id'],
                    'name' => $matched['name'],
                    'role' => $matched['role'],
                    'avatar' => $matched['avatar']
                ];
                header('Location: stylist_dashboard.php');
                exit;
            } else {
                $errorMsg = 'Không tìm thấy thông tin Thợ cắt tóc này!';
            }
        } else {
            $errorMsg = 'Vui lòng chọn Stylist!';
        }
    } elseif ($mode === 'admin_login') {
        $username = trim($_POST['username'] ?? '');
        $password = trim($_POST['password'] ?? '');

        if ($username === 'admin' && $password === '123456') {
            $_SESSION['admin'] = true;
            header('Location: admin.php');
            exit;
        } else {
            $errorMsg = 'Tên đăng nhập hoặc Mật khẩu Quản trị không đúng!';
        }
    }
}

$tab = $_GET['tab'] ?? 'login';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>LUMIÈRE Hair Studio - Cổng Đăng Nhập</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            salon: {
              bg: '#FBF9F5',
              surface: '#FFFFFF',
              primary: '#4A6B5D',
              secondary: '#C89F82',
              border: '#E7E0D8'
            }
          },
          fontFamily: {
            sans: ['"Plus Jakarta Sans"', 'sans-serif'],
            serif: ['"Playfair Display"', 'serif']
          }
        }
      }
    }
  </script>
</head>
<body class="bg-[#F8F6F0] min-h-screen flex items-center justify-center p-4">
  <div class="w-full max-w-4xl bg-white rounded-3xl border border-stone-200 shadow-2xl overflow-hidden grid md:grid-cols-12 min-h-[540px]">
    
    <!-- LEFT BANNER -->
    <div class="hidden md:flex md:col-span-5 relative bg-stone-900 p-8 text-white flex-col justify-between overflow-hidden">
      <img src="https://images.unsplash.com/photo-1560869713-7d0a29430803?auto=format&fit=crop&q=80&w=800" class="absolute inset-0 w-full h-full object-cover opacity-50 mix-blend-overlay" />
      <div class="relative z-10 space-y-2">
        <div class="w-12 h-12 rounded-full bg-salon-primary text-white flex items-center justify-center font-serif font-bold text-xl">L</div>
        <h2 class="font-serif text-2xl font-bold">LUMIÈRE Hair Studio</h2>
        <p class="text-xs text-stone-300">Hệ Thống Đặt Lịch & Quản Lý Ca Hẹn Stylist</p>
      </div>
      <div class="relative z-10 text-xs text-stone-400">© 2026 LUMIÈRE Hair Studio</div>
    </div>

    <!-- RIGHT FORM -->
    <div class="md:col-span-7 p-8 flex flex-col justify-between space-y-6 bg-white">
      <div class="space-y-2">
        <h1 class="font-serif text-2xl font-bold text-stone-900">Cổng Đăng Nhập Hệ Thống</h1>
        <p class="text-xs text-stone-500">Đăng nhập tài khoản Khách hàng, Cổng Stylist hoặc Trang Quản trị</p>
      </div>

      <?php if ($errorMsg): ?>
        <div class="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold">
          ⚠️ <?= htmlspecialchars($errorMsg) ?>
        </div>
      <?php endif; ?>

      <!-- TAB SELECTOR -->
      <div class="flex bg-stone-100 p-1 rounded-2xl border border-stone-200 gap-1">
        <button id="btnCustomerTab" onclick="switchTab('customer')" class="flex-1 py-2.5 rounded-xl text-[11px] font-bold bg-white text-stone-900 shadow">👤 Khách Hàng</button>
        <button id="btnStylistTab" onclick="switchTab('stylist')" class="flex-1 py-2.5 rounded-xl text-[11px] font-bold text-stone-500 hover:text-stone-900">✂️ Stylist</button>
        <button id="btnAdminTab" onclick="switchTab('admin')" class="flex-1 py-2.5 rounded-xl text-[11px] font-bold text-stone-500 hover:text-stone-900">🔐 Quản Trị</button>
      </div>

      <!-- CUSTOMER FORM -->
      <form id="formCustomer" method="POST" class="space-y-4">
        <input type="hidden" name="mode" value="customer_login" />
        <div>
          <label class="block text-xs font-bold uppercase text-stone-700 mb-1">Số Điện Thoại Khách Hàng</label>
          <input type="tel" name="phone" required placeholder="0912345678" value="0912345678" class="w-full px-4 py-3 rounded-2xl border border-stone-200 text-sm focus:ring-2 focus:ring-salon-primary focus:outline-none" />
        </div>
        <div>
          <label class="block text-xs font-bold uppercase text-stone-700 mb-1">Mật Khẩu</label>
          <input type="password" name="password" required value="123456" class="w-full px-4 py-3 rounded-2xl border border-stone-200 text-sm focus:ring-2 focus:ring-salon-primary focus:outline-none" />
        </div>
        <button type="submit" class="w-full py-3.5 rounded-2xl bg-salon-primary hover:bg-stone-800 text-white font-bold text-xs shadow-lg transition">
          🚀 ĐĂNG NHẬP KHÁCH HÀNG
        </button>
      </form>

      <!-- STYLIST FORM -->
      <form id="formStylist" method="POST" class="space-y-4 hidden">
        <input type="hidden" name="mode" value="stylist_login" />
        <div>
          <label class="block text-xs font-bold uppercase text-stone-700 mb-1">Chọn Tên Thợ Cắt Tóc / Stylist</label>
          <select name="stylist_name" class="w-full px-4 py-3 rounded-2xl border border-stone-200 text-sm focus:ring-2 focus:ring-salon-primary focus:outline-none">
            <?php foreach ($db['stylists'] as $st): ?>
              <?php if (($st['isAny'] ?? 0) == 1) continue; ?>
              <option value="<?= htmlspecialchars($st['name']) ?>"><?= htmlspecialchars($st['name']) ?> - <?= htmlspecialchars($st['role']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label class="block text-xs font-bold uppercase text-stone-700 mb-1">Mật Khẩu Stylist (Mặc định: 123456)</label>
          <input type="password" name="password" required value="123456" class="w-full px-4 py-3 rounded-2xl border border-stone-200 text-sm focus:ring-2 focus:ring-salon-primary focus:outline-none" />
        </div>
        <button type="submit" class="w-full py-3.5 rounded-2xl bg-[#C89F82] hover:bg-stone-800 text-white font-bold text-xs shadow-lg transition">
          ✂️ ĐĂNG NHẬP CỔNG STYLIST
        </button>
      </form>

      <!-- ADMIN FORM -->
      <form id="formAdmin" method="POST" class="space-y-4 hidden">
        <input type="hidden" name="mode" value="admin_login" />
        <div>
          <label class="block text-xs font-bold uppercase text-stone-700 mb-1">Tên Đăng Nhập Quản Trị</label>
          <input type="text" name="username" required placeholder="admin" value="admin" class="w-full px-4 py-3 rounded-2xl border border-stone-200 text-sm focus:ring-2 focus:ring-salon-primary focus:outline-none" />
        </div>
        <div>
          <label class="block text-xs font-bold uppercase text-stone-700 mb-1">Mật Khẩu Quản Trị</label>
          <input type="password" name="password" required value="123456" class="w-full px-4 py-3 rounded-2xl border border-stone-200 text-sm focus:ring-2 focus:ring-salon-primary focus:outline-none" />
        </div>
        <button type="submit" class="w-full py-3.5 rounded-2xl bg-stone-900 hover:bg-stone-800 text-white font-bold text-xs shadow-lg transition">
          🔓 ĐĂNG NHẬP QUẢN TRỊ VIÊN
        </button>
      </form>

      <div class="text-center">
        <a href="index.php" class="text-xs text-salon-primary font-bold hover:underline">← Quay về Trang chủ</a>
      </div>
    </div>
  </div>

  <script>
    const activeTab = "<?= $tab ?>";

    function switchTab(tab) {
      document.getElementById('formCustomer').classList.add('hidden');
      document.getElementById('formStylist').classList.add('hidden');
      document.getElementById('formAdmin').classList.add('hidden');

      document.getElementById('btnCustomerTab').className = "flex-1 py-2.5 rounded-xl text-[11px] font-bold text-stone-500 hover:text-stone-900";
      document.getElementById('btnStylistTab').className = "flex-1 py-2.5 rounded-xl text-[11px] font-bold text-stone-500 hover:text-stone-900";
      document.getElementById('btnAdminTab').className = "flex-1 py-2.5 rounded-xl text-[11px] font-bold text-stone-500 hover:text-stone-900";

      if (tab === 'stylist') {
        document.getElementById('formStylist').classList.remove('hidden');
        document.getElementById('btnStylistTab').className = "flex-1 py-2.5 rounded-xl text-[11px] font-bold bg-white text-stone-900 shadow";
      } else if (tab === 'admin') {
        document.getElementById('formAdmin').classList.remove('hidden');
        document.getElementById('btnAdminTab').className = "flex-1 py-2.5 rounded-xl text-[11px] font-bold bg-white text-stone-900 shadow";
      } else {
        document.getElementById('formCustomer').classList.remove('hidden');
        document.getElementById('btnCustomerTab').className = "flex-1 py-2.5 rounded-xl text-[11px] font-bold bg-white text-stone-900 shadow";
      }
    }

    if (activeTab === 'admin' || activeTab === 'stylist') {
      switchTab(activeTab);
    }
  </script>
</body>
</html>
