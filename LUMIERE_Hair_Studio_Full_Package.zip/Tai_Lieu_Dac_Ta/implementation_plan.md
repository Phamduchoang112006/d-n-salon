# Kế Hoạch Triển Khai: Nâng Cấp Hệ Thống LUMIÈRE Hair Studio Lên Chuẩn Enterprise Salon ERP

Kế hoạch này chi tiết hóa việc nâng cấp toàn bộ hệ thống LUMIÈRE Hair Studio với 6 phân hệ tính năng cao cấp, biến website thành hệ thống Quản trị Salon ERP chuyên nghiệp hoàn chỉnh.

---

## 🏛️ 1. Danh Sách Phân Hệ Nâng Cấp Chi Tiết

### A. Phân Hệ Thanh Toán VietQR & Coupon Giảm Giá (Client Portal)
1. **Thanh Toán VietQR Đặt Cọc Tự Động (VietQR Napas247)**:
   - Tự động tạo mã QR VietQR động (`https://img.vietqr.io/image/...`) ở Bước 4 & 5 của quy trình đặt lịch.
   - Mã QR chứa sẵn tên ngân hàng, số tài khoản salon, số tiền cọc 20% và **Cú pháp chuyển khoản tự động**: `LUMI-[Mã_Đơn_Hẹn]`.
2. **Hệ Thống Voucher / Promo Code**:
   - Ô nhập mã giảm giá ở Bước 4 đặt lịch (vd: `LUMIERE2026` giảm 10%, `SALON100K` giảm 100.000₫).
   - Kiểm tra điều kiện đơn hàng tối thiểu và tính toán giảm giá thời gian thực.
3. **Cổng Lịch Sử & Tích Điểm Khách Hàng (`customer_portal.php`)**:
   - Khách xem lịch sử làm tóc, số dư điểm thưởng (Loyalty Points) và Hạng thành viên (Đồng, Bạc, Vàng, Kim Cương).

### B. Phân Hệ Quản Lý Kho Hóa Chất & Định Mức Dịch Vụ (`admin_inventory.php`)
1. **Quản Lý Vật Tư & Hóa Chất Salon**:
   - Bảng quản lý kho thuốc nhuộm, thuốc uốn, dầu gội, Keratin với mức tồn kho tối thiểu (Min Threshold).
   - Cảnh báo màu đỏ khi vật tư sắp hết (Low Stock Alert).
2. **Khấu Trừ Hóa Chất Tự Động (Auto Stock Deduction)**:
   - Khi ca hẹn chuyển sang trạng thái `Completed`, hệ thống tự động bóc tách các dịch vụ và trừ số lượng hóa chất tương ứng khỏi kho (vd: Nhuộm Premium tự trừ 100ml thuốc nhuộm).

### C. Phân Hệ Phân Ca & Xin Nghỉ Phép Thợ (`admin_leaves.php` & Stylist Portal)
1. **Stylist Xin Nghỉ Phép**:
   - Thợ gửi đơn xin nghỉ phép trên `stylist_dashboard.php`.
   - Admin phê duyệt đơn nghỉ trên Admin Portal.
2. **Khóa Lịch Tự Động**:
   - Khi đơn nghỉ được duyệt, thuật toán `is_stylist_busy_at_slot()` tự động khóa toàn bộ khung giờ của thợ đó trong ngày nghỉ.

### D. Phân Hệ Báo Cáo Analytics BI Chart.js (`admin.php`)
1. **Biểu Đồ Doanh Thu & Ca Hẹn**:
   - Tích hợp thư viện Chart.js hiển thị biểu đồ đường (Line chart) doanh thu theo ngày/tháng.
2. **Biểu Đồ Tỷ Lệ Dịch Vụ Hot & Khung Giờ Vàng**:
   - Biểu đồ tròn (Doughnut chart) thống kê loại dịch vụ yêu thích nhất và khung giờ đông khách nhất.

### E. Thông Báo Âm Thanh Real-Time & Gửi SMS/Email Gateway
1. **Âm Thanh Thông Báo Đơn Mới (Real-time Audio Alert)**:
   - Phát tiếng chuông thông báo (Web Audio API) khi có đơn hẹn mới hoặc tin nhắn chat từ khách.
2. **Mô Đun Gửi SMS/Email Gateway (`notification_gateway.php`)**:
   - Chuẩn hóa module gửi tin nhắn SMS Brandname / Email SMTP qua PHPMailer / Esms API.

### F. AI Virtual Hair Try-On Simulator
1. **Thử Kiểu Tóc & Màu Nhuộm AI**:
   - Modal cho phép khách hàng upload ảnh khuôn mặt và thử nghiệm xem trước hiệu ứng màu nhuộm (Nâu trà sữa, Nâu lạnh, Hồng ánh kim) trên nền ảnh thực tế.

---

## 🛠️ 2. Các Thay Đổi Chi Tiết Theo Tệp (Files Breakdown)

### [Database & Core Logic]

#### [MODIFY] [database.sql](file:///c:/Users/Admin/ReactNative24cntt1a/database.sql)
- Thêm các bảng mới: `inventory`, `vouchers`, `stylist_leaves`, `service_materials`.
- Thêm cột `loyalty_points` và `membership_tier` vào bảng `users`.

#### [MODIFY] [db.php](file:///c:/Users/Admin/ReactNative24cntt1a/db.php)
- Cập nhật hàm `is_stylist_busy_at_slot()` để kiểm tra thêm lịch nghỉ phép đã duyệt (`stylist_leaves`).
- Thêm các hàm quản lý kho `deduct_inventory_for_appointment()` và quản lý voucher `validate_voucher()`.

#### [MODIFY] [api.php](file:///c:/Users/Admin/ReactNative24cntt1a/api.php)
- Thêm endpoints: `apply_voucher`, `get_customer_history`, `submit_leave_request`, `approve_leave_request`, `get_inventory_list`, `update_stock`.

---

### [Admin & Stylist Portals]

#### [NEW] [admin_inventory.php](file:///c:/Users/Admin/ReactNative24cntt1a/admin_inventory.php)
- Giao diện quản lý kho hóa chất salon, nhập/xóa vật tư và cảnh báo hết hàng.

#### [NEW] [admin_leaves.php](file:///c:/Users/Admin/ReactNative24cntt1a/admin_leaves.php)
- Giao diện duyệt đơn xin nghỉ phép của thợ stylist.

#### [MODIFY] [admin.php](file:///c:/Users/Admin/ReactNative24cntt1a/admin.php)
- Tích hợp Chart.js hiển thị 3 biểu đồ Analytics (Doanh thu, Dịch vụ Hot, Khung giờ đông khách).

#### [MODIFY] [admin_nav.php](file:///c:/Users/Admin/ReactNative24cntt1a/admin_nav.php)
- Thêm 2 menu items: `📦 Quản Lý Kho` (`admin_inventory.php`) và `📅 Duyệt Nghỉ Phép` (`admin_leaves.php`).

#### [MODIFY] [stylist_dashboard.php](file:///c:/Users/Admin/ReactNative24cntt1a/stylist_dashboard.php)
- Thêm form xin nghỉ phép và xem lịch sử đơn xin nghỉ của bản thân.

---

### [Client Website & AI Simulator]

#### [NEW] [customer_portal.php](file:///c:/Users/Admin/ReactNative24cntt1a/customer_portal.php)
- Cổng thông tin khách hàng: Tra cứu lịch sử ca hẹn, điểm thưởng và hạng thẻ thành viên.

#### [MODIFY] [index.php](file:///c:/Users/Admin/ReactNative24cntt1a/index.php)
- Bước 4: Thêm VietQR Napas247 Dynamic QR Code + Ô nhập Voucher giảm giá.
- Thêm Widget **📸 AI Virtual Hair Try-On** hỗ trợ tải ảnh cá nhân và ghép thử màu nhuộm thời trang.

---

## 📊 3. Kế Hoạch Kiểm Thử (Verification Plan)

### Automated & Database Verification
1. Chạy script tạo mới các bảng CSDL `inventory`, `vouchers`, `stylist_leaves`, `service_materials`.
2. Kiểm tra tính hợp lệ của việc tự động trừ tồn kho khi đơn hẹn chuyển sang `Completed`.
3. Kiểm tra logic khóa giờ tự động khi đơn nghỉ phép thợ được duyệt.

### Manual Verification
1. Test thử VietQR: Mở Bước 4 đặt lịch, quét thử QR VietQR hiển thị đúng thông tin cọc và nội dung `LUMI-xxxx`.
2. Test thử Voucher: Nhập `LUMIERE2026` xem tổng tiền có được giảm trừ hợp lệ.
3. Test thử Kho hàng: Đổi đơn sang `Completed`, kiểm tra kho hóa chất tự động giảm 100ml.
4. Test thử Duyệt nghỉ phép: Cho thợ nghỉ ngày mai $\rightarrow$ Kiểm tra trang `index.php` thợ đó lập tức bị khóa lịch ngày mai.
5. Test thử AI Hair Try-On: Upload ảnh và thử đổi màu nhuộm trực tiếp.
