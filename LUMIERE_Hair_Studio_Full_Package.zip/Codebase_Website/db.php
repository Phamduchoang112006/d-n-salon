<?php
// db.php - Module kết nối Cơ Sở Dữ Liệu SQL (MySQL phpMyAdmin / SQLite) qua PHP PDO

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// CẤU HÌNH LOẠI DATABASE: 'mysql' (Đã kết nối với phpMyAdmin) hoặc 'sqlite'
define('DB_TYPE', 'mysql');

// Cấu hình MySQL / phpMyAdmin
define('MYSQL_HOST', '127.0.0.1');
define('MYSQL_PORT', '3306');
define('MYSQL_DB', 'lumiere_salon');
define('MYSQL_USER', 'root');
define('MYSQL_PASS', '');

// Cấu hình SQLite File Path (Dự phòng)
define('SQLITE_FILE', __DIR__ . '/data/salon.db');

/**
 * Lấy đối tượng kết nối PDO Database
 */
function get_pdo() {
    static $pdo = null;
    if ($pdo !== null) return $pdo;

    try {
        if (DB_TYPE === 'mysql') {
            $dsn = 'mysql:host=' . MYSQL_HOST . ';port=' . MYSQL_PORT . ';dbname=' . MYSQL_DB . ';charset=utf8mb4';
            $pdo = new PDO($dsn, MYSQL_USER, MYSQL_PASS);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        } else {
            $dir = dirname(SQLITE_FILE);
            if (!is_dir($dir)) {
                mkdir($dir, 0777, true);
            }
            $need_init = !file_exists(SQLITE_FILE);
            $pdo = new PDO('sqlite:' . SQLITE_FILE);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

            if ($need_init) {
                $sql_file = __DIR__ . '/database.sql';
                if (file_exists($sql_file)) {
                    $sql = file_get_contents($sql_file);
                    $pdo->exec($sql);
                }
            }
        }
        return $pdo;
    } catch (PDOException $e) {
        die('Lỗi kết nối Cơ sở dữ liệu: ' . $e->getMessage());
    }
}

/**
 * Đọc toàn bộ dữ liệu từ SQL Database
 */
function get_db() {
    $pdo = get_pdo();

    $services = $pdo->query("SELECT * FROM services")->fetchAll();
    $hairstyles = $pdo->query("SELECT * FROM hairstyles")->fetchAll();
    $haircolors = $pdo->query("SELECT * FROM haircolors")->fetchAll();
    $stylists = $pdo->query("SELECT * FROM stylists")->fetchAll();
    $reviews = $pdo->query("SELECT * FROM reviews ORDER BY id DESC")->fetchAll();
    $users = $pdo->query("SELECT * FROM users")->fetchAll();
    $appointments = $pdo->query("SELECT * FROM appointments ORDER BY createdTime DESC")->fetchAll();

    // Decode JSON services in appointments
    foreach ($appointments as &$app) {
        if (!empty($app['services'])) {
            $decoded = json_decode($app['services'], true);
            if (is_string($decoded)) {
                $decoded = json_decode($decoded, true);
            }
            if (is_array($decoded)) {
                $app['services'] = array_map(function($s) {
                    return trim($s, "[]\"'\\ \t\n\r\0\x0B");
                }, $decoded);
            } else {
                $clean = trim($app['services'], "[]\"'\\ \t\n\r\0\x0B");
                $app['services'] = [$clean];
            }
        } else {
            $app['services'] = [];
        }
    }

    return [
        'services' => $services,
        'hairstyles' => $hairstyles,
        'haircolors' => $haircolors,
        'stylists' => $stylists,
        'reviews' => $reviews,
        'users' => $users,
        'appointments' => $appointments
    ];
}

/**
 * Chuyển mã trạng thái sang Tiếng Việt
 */
function get_status_label($st) {
    switch ($st) {
        case 'Pending': return 'Chờ xác nhận';
        case 'Confirmed': return 'Đã xác nhận';
        case 'InProgress': return 'Đang thực hiện';
        case 'Completed': return 'Đã hoàn thành';
        case 'Cancelled': return 'Đã hủy';
        default: return $st;
    }
}

/**
 * Định dạng tiền tệ VND
 */
function format_vnd($number) {
    return number_format($number, 0, ',', '.') . ' ₫';
}

/**
 * Lấy thông tin người dùng đang đăng nhập từ Session
 */
function get_logged_user() {
    return $_SESSION['user'] ?? null;
}

/**
 * Kiểm tra Admin đã đăng nhập hay chưa
 */
function is_admin_logged_in() {
    return !empty($_SESSION['admin']) && $_SESSION['admin'] === true;
}

/**
 * Kiểm tra Stylist đã đăng nhập hay chưa
 */
function is_stylist_logged_in() {
    return !empty($_SESSION['stylist']);
}

/**
 * Lấy thông tin Stylist đang đăng nhập từ Session
 */
function get_logged_stylist() {
    return $_SESSION['stylist'] ?? null;
}

/**
 * Chuyển chuỗi giờ "HH:MM" sang số phút tính từ 00:00
 */
function parse_time_to_minutes($timeStr) {
    $timeStr = trim($timeStr);
    if (preg_match('/^(\d{1,2}):(\d{2})$/', $timeStr, $m)) {
        return intval($m[1]) * 60 + intval($m[2]);
    }
    return 540;
}

/**
 * Tính tổng số phút phục vụ dựa trên danh sách tên Dịch vụ
 */
function calculate_services_duration($pdo, $servicesArr) {
    if (empty($servicesArr)) return 45;
    $placeholders = implode(',', array_fill(0, count($servicesArr), '?'));
    $stmt = $pdo->prepare("SELECT SUM(IFNULL(minutes, 45)) as total_min FROM services WHERE name IN ($placeholders)");
    $stmt->execute(array_values($servicesArr));
    $res = $stmt->fetchColumn();
    return max(intval($res), 30);
}

/**
 * Kiểm tra Stylist có bị bận/trùng ca hoặc đang NGHỈ PHÉP tại khung giờ chọn hay không
 */
function is_stylist_busy_at_slot($pdo, $stylistName, $date, $candStart, $candDuration) {
    // 1. Kiểm tra đơn xin nghỉ phép đã được duyệt (Approved Leave)
    $stmtLeave = $pdo->prepare("SELECT COUNT(*) FROM stylist_leaves WHERE stylist_name = ? AND leave_date = ? AND status = 'Approved'");
    $stmtLeave->execute([$stylistName, $date]);
    if ($stmtLeave->fetchColumn() > 0) {
        return true; // Stylist nghỉ phép nguyên ngày
    }

    // 2. Kiểm tra trùng ca hẹn khác
    $candEnd = $candStart + $candDuration;

    $stmt = $pdo->prepare("SELECT services, time FROM appointments WHERE stylist = ? AND date = ? AND status IN ('Pending', 'Confirmed', 'InProgress')");
    $stmt->execute([$stylistName, $date]);
    $existingApps = $stmt->fetchAll();

    foreach ($existingApps as $app) {
        $existStart = parse_time_to_minutes($app['time']);
        $svcs = json_decode($app['services'], true) ?: [$app['services']];
        $existDur = calculate_services_duration($pdo, $svcs);
        $existEnd = $existStart + $existDur;

        if (($candStart < $existEnd) && ($candEnd > $existStart)) {
            return true;
        }
    }

    return false;
}

/**
 * Tự động trừ kho hóa chất khi đơn hẹn chuyển sang Completed
 */
function deduct_inventory_for_appointment($pdo, $appointmentId) {
    $stmt = $pdo->prepare("SELECT services FROM appointments WHERE id = ?");
    $stmt->execute([$appointmentId]);
    $app = $stmt->fetch();
    if (!$app) return false;

    $services = json_decode($app['services'], true) ?: [$app['services']];

    foreach ($services as $svcName) {
        $stmtMat = $pdo->prepare("SELECT item_name, quantity_used FROM service_materials WHERE service_name = ?");
        $stmtMat->execute([$svcName]);
        $mats = $stmtMat->fetchAll();

        foreach ($mats as $m) {
            $stmtDeduct = $pdo->prepare("UPDATE inventory SET quantity = GREATEST(0, quantity - ?) WHERE item_name = ?");
            $stmtDeduct->execute([$m['quantity_used'], $m['item_name']]);
        }
    }
    return true;
}

/**
 * Kiểm tra và áp dụng Mã Giảm Giá (Voucher)
 */
function validate_voucher($pdo, $code, $spendAmount) {
    $stmt = $pdo->prepare("SELECT * FROM vouchers WHERE code = ? AND (expiry_date >= CURDATE() OR expiry_date IS NULL)");
    $stmt->execute([trim($code)]);
    $v = $stmt->fetch();

    if (!$v) {
        return ['valid' => false, 'message' => 'Mã giảm giá không tồn tại hoặc đã hết hạn!'];
    }

    if ($spendAmount < intval($v['min_spend'])) {
        return ['valid' => false, 'message' => 'Đơn hàng tối thiểu ' . number_format($v['min_spend']) . ' ₫ để sử dụng mã này!'];
    }

    $discount = 0;
    if ($v['discount_type'] === 'percent') {
        $discount = round(($spendAmount * intval($v['discount_value'])) / 100);
        if ($v['max_discount'] > 0 && $discount > intval($v['max_discount'])) {
            $discount = intval($v['max_discount']);
        }
    } else {
        $discount = intval($v['discount_value']);
    }

    return [
        'valid' => true,
        'code' => $v['code'],
        'discountAmount' => $discount,
        'finalTotal' => max(0, $spendAmount - $discount),
        'message' => 'Áp dụng mã ' . $v['code'] . ' thành công! Giảm ' . number_format($discount) . ' ₫'
    ];
}

/**
 * Hàm trả về JSON Response cho AJAX
 */
function response_json($status, $message, $extra = []) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(array_merge([
        'status' => $status,
        'message' => $message
    ], $extra), JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * Tra cứu % Hoa hồng dựa trên Cấp Bậc Thợ (Master/Senior/Junior) và Loại Dịch Vụ
 */
function get_commission_rate($level, $category) {
    $level = ucfirst(strtolower($level ?? 'Senior'));
    $cat = trim($category ?? '');

    // Ma trận Tỷ lệ Hoa hồng
    $matrix = [
        'Master' => [
            'Uốn & Nhuộm' => 0.20,
            'Cắt & Tạo Kiểu' => 0.15,
            'Chăm Sóc & Phục Hồi' => 0.12,
            'default' => 0.15
        ],
        'Senior' => [
            'Uốn & Nhuộm' => 0.15,
            'Cắt & Tạo Kiểu' => 0.12,
            'Chăm Sóc & Phục Hồi' => 0.10,
            'default' => 0.12
        ],
        'Junior' => [
            'Uốn & Nhuộm' => 0.10,
            'Cắt & Tạo Kiểu' => 0.08,
            'Chăm Sóc & Phục Hồi' => 0.08,
            'default' => 0.08
        ]
    ];

    if (!isset($matrix[$level])) {
        $level = 'Senior';
    }

    if (isset($matrix[$level][$cat])) {
        return $matrix[$level][$cat];
    }
    return $matrix[$level]['default'];
}

/**
 * Tính toán Hoa hồng chi tiết cho một Ca Hẹn đã Hoàn Thành
 */
function calculate_appointment_commission($app, $stylistObj = null) {
    $pdo = get_pdo();

    if (!$stylistObj && !empty($app['stylist'])) {
        $stmt = $pdo->prepare("SELECT * FROM stylists WHERE name = ?");
        $stmt->execute([$app['stylist']]);
        $stylistObj = $stmt->fetch();
    }

    $level = $stylistObj['level'] ?? 'Senior';
    $servicesList = is_array($app['services']) ? $app['services'] : (json_decode($app['services'], true) ?: [$app['services']]);

    $servicesBreakdown = [];
    $totalCommission = 0;
    $appTotalPrice = intval($app['totalPrice'] ?? 0);

    if (!empty($servicesList)) {
        // Fetch service details from DB
        $placeholders = implode(',', array_fill(0, count($servicesList), '?'));
        $stmt = $pdo->prepare("SELECT * FROM services WHERE name IN ($placeholders)");
        $stmt->execute(array_values($servicesList));
        $fetchedSvcs = $stmt->fetchAll();

        $svcMap = [];
        $sumSvcPrices = 0;
        foreach ($fetchedSvcs as $s) {
            $svcMap[$s['name']] = $s;
            $sumSvcPrices += intval($s['price']);
        }

        foreach ($servicesList as $sName) {
            $svcData = $svcMap[$sName] ?? null;
            $cat = $svcData['category'] ?? 'Khác';

            // Price allocation
            if ($svcData) {
                $svcPrice = intval($svcData['price']);
                if ($sumSvcPrices > 0 && $appTotalPrice > 0 && $sumSvcPrices != $appTotalPrice) {
                    // Proportionally scale if appointment had discount/package
                    $svcPrice = round(($svcPrice / $sumSvcPrices) * $appTotalPrice);
                }
            } else {
                $svcPrice = ($sumSvcPrices > 0) ? round($appTotalPrice / count($servicesList)) : $appTotalPrice;
            }

            $rate = get_commission_rate($level, $cat);
            $commission = round($svcPrice * $rate);
            $totalCommission += $commission;

            $servicesBreakdown[] = [
                'serviceName' => $sName,
                'category' => $cat,
                'price' => $svcPrice,
                'rate' => $rate,
                'ratePercent' => ($rate * 100) . '%',
                'commission' => $commission
            ];
        }
    }

    return [
        'totalCommission' => $totalCommission,
        'level' => $level,
        'servicesBreakdown' => $servicesBreakdown
    ];
}

/**
 * Tổng hợp Báo Cáo Lương Cuối Tháng cho Toàn Bộ Thợ
 */
function get_monthly_salary_report($selectedMonthYear = null) {
    $pdo = get_pdo();

    if (!$selectedMonthYear) {
        $selectedMonthYear = date('m/Y');
    }

    // Standardize month & year search pattern
    // e.g. "09/2026" or "2026-09"
    $parts = explode('/', str_replace('-', '/', $selectedMonthYear));
    if (count($parts) === 2) {
        if (strlen($parts[0]) === 4) {
            $yearStr = $parts[0];
            $monthStr = str_pad($parts[1], 2, '0', STR_PAD_LEFT);
        } else {
            $monthStr = str_pad($parts[0], 2, '0', STR_PAD_LEFT);
            $yearStr = $parts[1];
        }
    } else {
        $monthStr = date('m');
        $yearStr = date('Y');
    }

    // Fetch all stylists (exclude 'any')
    $stylists = $pdo->query("SELECT * FROM stylists WHERE isAny = 0 ORDER BY FIELD(level, 'Master', 'Senior', 'Junior'), name ASC")->fetchAll();

    // Fetch all completed appointments
    $apps = $pdo->query("SELECT * FROM appointments WHERE status = 'Completed'")->fetchAll();

    $report = [];
    $totalSalonRevenue = 0;
    $totalSalonCommission = 0;
    $totalSalonBaseSalary = 0;
    $totalSalonPayout = 0;
    $totalCompletedApps = 0;

    foreach ($stylists as $st) {
        $stName = $st['name'];
        $stLevel = $st['level'] ?? 'Senior';
        $baseSalary = intval($st['baseSalary'] ?? 8000000);

        $stCompletedApps = [];
        $stRevenue = 0;
        $stCommission = 0;

        foreach ($apps as $a) {
            if ($a['stylist'] !== $stName) continue;

            // Date filtering check: e.g. "05/09/2026" or "Hôm nay" (if today is in month)
            $aDate = $a['date'] ?? '';
            $isMatch = false;

            if (strpos($aDate, 'Hôm nay') !== false) {
                if (date('m') === $monthStr && date('Y') === $yearStr) {
                    $isMatch = true;
                }
            } else if (preg_match('/(\d{1,2})\/(\d{1,2})\/(\d{4})/', $aDate, $m)) {
                $appM = str_pad($m[2], 2, '0', STR_PAD_LEFT);
                $appY = $m[3];
                if ($appM === $monthStr && $appY === $yearStr) {
                    $isMatch = true;
                }
            } else {
                // Default match if no specific date format block
                $isMatch = true;
            }

            if ($isMatch) {
                // Decode services if needed
                if (!is_array($a['services'])) {
                    $decoded = json_decode($a['services'], true);
                    $a['services'] = is_array($decoded) ? $decoded : [$a['services']];
                }

                $commInfo = calculate_appointment_commission($a, $st);
                $a['commissionInfo'] = $commInfo;

                $stCompletedApps[] = $a;
                $stRevenue += intval($a['totalPrice'] ?? 0);
                $stCommission += $commInfo['totalCommission'];
            }
        }

        $totalEarnings = $baseSalary + $stCommission;

        $totalSalonRevenue += $stRevenue;
        $totalSalonCommission += $stCommission;
        $totalSalonBaseSalary += $baseSalary;
        $totalSalonPayout += $totalEarnings;
        $totalCompletedApps += count($stCompletedApps);

        $report[] = [
            'stylist' => $st,
            'completedCount' => count($stCompletedApps),
            'revenue' => $stRevenue,
            'baseSalary' => $baseSalary,
            'commission' => $stCommission,
            'totalPayout' => $totalEarnings,
            'appointments' => $stCompletedApps
        ];
    }

    return [
        'monthYear' => $monthStr . '/' . $yearStr,
        'summary' => [
            'totalCompletedCount' => $totalCompletedApps,
            'totalSalonRevenue' => $totalSalonRevenue,
            'totalSalonCommission' => $totalSalonCommission,
            'totalSalonBaseSalary' => $totalSalonBaseSalary,
            'totalSalonPayout' => $totalSalonPayout
        ],
        'stylistsReport' => $report
    ];
}

