<?php
// ============================================================
// HỆ THỐNG QUẢN LÝ THƯ VIỆN & TIỆM THUÊ TRUYỆN ENTERPRISE 4.0
// RESTful Backend API - XÁC THỰC ĐĂNG KÝ / ĐĂNG NHẬP (AUTH)
// Nhóm: Nguyễn Đăng Khải (Leader), Nguyễn Nhật Linh Ân, Phan Duy
// ============================================================

require_once __DIR__ . '/library_db.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
    exit;
}

$pdo = get_lib_pdo();
$action = $_REQUEST['action'] ?? '';

$input_json = json_decode(file_get_contents('php://input'), true) ?? [];
$data = array_merge($_REQUEST, $input_json);

try {
    switch ($action) {

        // ============================================================
        // A. XÁC THỰC QUẢN TRỊ VIÊN (ADMIN AUTHENTICATION)
        // ============================================================
        case 'admin_login':
            $username = trim($data['username'] ?? '');
            $password = trim($data['password'] ?? '');

            if (!$username || !$password) {
                lib_response('error', 'Vui lòng nhập Tên đăng nhập và Mật khẩu Quản trị');
            }

            $stmt = $pdo->prepare("SELECT * FROM admins WHERE username=? OR email=?");
            $stmt->execute([$username, $username]);
            $admin = $stmt->fetch();

            if (!$admin) {
                lib_response('error', 'Tài khoản Quản trị viên không tồn tại!');
            }

            // Kiểm tra mật khẩu (hỗ trợ so sánh trực tiếp hoặc password_hash)
            if ($password !== $admin['password_hash'] && !password_verify($password, $admin['password_hash'])) {
                lib_response('error', 'Mật khẩu Quản trị viên không chính xác!');
            }

            $_SESSION['admin_user'] = $admin;
            lib_response('success', 'Đăng nhập Quản trị viên thành công!', [
                'user' => [
                    'id' => $admin['id'],
                    'username' => $admin['username'],
                    'full_name' => $admin['full_name'],
                    'email' => $admin['email'],
                    'role' => $admin['role']
                ]
            ]);
            break;

        case 'admin_register':
            $username = trim($data['username'] ?? '');
            $password = trim($data['password'] ?? '');
            $full_name = trim($data['full_name'] ?? '');
            $email = trim($data['email'] ?? '');

            if (!$username || !$password || !$full_name || !$email) {
                lib_response('error', 'Vui lòng nhập đầy đủ thông tin đăng ký Quản trị viên');
            }

            // Kiểm tra trùng lặp
            $check = $pdo->prepare("SELECT id FROM admins WHERE username=? OR email=?");
            $check->execute([$username, $email]);
            if ($check->fetch()) {
                lib_response('error', 'Tên đăng nhập hoặc Email này đã được sử dụng!');
            }

            $stmt = $pdo->prepare("INSERT INTO admins (username, password_hash, full_name, email, role) VALUES (?, ?, ?, ?, 'Quản trị viên')");
            $stmt->execute([$username, $password, $full_name, $email]);

            lib_response('success', 'Đăng ký tài khoản Quản trị viên thành công! Bạn có thể đăng nhập ngay.');
            break;

        // ============================================================
        // B. XÁC THỰC ĐỘC GIẢ / NGƯỜI THUÊ (READER / CUSTOMER AUTH)
        // ============================================================
        case 'reader_login':
            $email_or_phone = trim($data['email'] ?? $data['so_dien_thoai'] ?? $data['username'] ?? '');
            $password = trim($data['password'] ?? '');

            if (!$email_or_phone || !$password) {
                lib_response('error', 'Vui lòng nhập Email/SĐT và Mật khẩu');
            }

            $stmt = $pdo->prepare("SELECT * FROM readers WHERE email=? OR so_dien_thoai=? OR ma_doc_gia=?");
            $stmt->execute([$email_or_phone, $email_or_phone, $email_or_phone]);
            $reader = $stmt->fetch();

            if (!$reader) {
                lib_response('error', 'Tài khoản Độc giả không tồn tại!');
            }

            if ($reader['trang_thai'] !== 'Hoạt động') {
                lib_response('error', 'Tài khoản của bạn hiện đã bị khóa. Vui lòng liên hệ Thủ thư!');
            }

            $pass_check = ($password === $reader['mat_khau_hash']) || password_verify($password, $reader['mat_khau_hash']);
            if (!$pass_check) {
                lib_response('error', 'Mật khẩu Độc giả không chính xác!');
            }

            $_SESSION['reader_user'] = $reader;
            lib_response('success', 'Đăng nhập Độc giả thành công!', [
                'reader' => [
                    'id' => $reader['id'],
                    'ma_doc_gia' => $reader['ma_doc_gia'],
                    'ho_ten' => $reader['ho_ten'],
                    'email' => $reader['email'],
                    'so_dien_thoai' => $reader['so_dien_thoai'],
                    'so_du_vi' => (float)$reader['so_du_vi'],
                    'tien_coc_dong_bang' => (float)$reader['tien_coc_dong_bang'],
                    'loai_doc_gia' => $reader['loai_doc_gia']
                ]
            ]);
            break;

        case 'reader_register':
            $ho_ten = trim($data['ho_ten'] ?? '');
            $email = trim($data['email'] ?? '');
            $so_dien_thoai = trim($data['so_dien_thoai'] ?? '');
            $password = trim($data['password'] ?? '');
            $dia_chi = trim($data['dia_chi'] ?? 'Đà Nẵng');

            if (!$ho_ten || !$email || !$so_dien_thoai || !$password) {
                lib_response('error', 'Vui lòng điền đầy đủ Họ tên, Email, SĐT và Mật khẩu');
            }

            // Kiểm tra trùng Email/SĐT
            $check = $pdo->prepare("SELECT id FROM readers WHERE email=? OR so_dien_thoai=?");
            $check->execute([$email, $so_dien_thoai]);
            if ($check->fetch()) {
                lib_response('error', 'Email hoặc Số điện thoại này đã được đăng ký trước đó!');
            }

            $ma_doc_gia = 'DG' . rand(100, 999);
            $ngay_cap = date('Y-m-d');
            $han_the = date('Y-m-d', strtotime('+3 years'));

            $stmt = $pdo->prepare("INSERT INTO readers (ma_doc_gia, ho_ten, email, so_dien_thoai, mat_khau_hash, dia_chi, ngay_cap, han_the, so_du_vi, loai_doc_gia, trang_thai) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 500000.00, 'Sinh viên', 'Hoạt động')");
            $stmt->execute([$ma_doc_gia, $ho_ten, $email, $so_dien_thoai, $password, $dia_chi, $ngay_cap, $han_the]);
            $new_id = $pdo->lastInsertId();

            // Tặng bonus 500,000 VND vào ví trải nghiệm
            $pdo->prepare("INSERT INTO wallet_transactions (reader_id, ma_giao_dich, loai_giao_dich, so_tien, mo_ta) VALUES (?, ?, 'Nạp tiền', 500000.00, 'Tặng bonus 500,000 VND khi đăng ký tài khoản mới')")
                ->execute([$new_id, 'WT-BONUS-' . rand(1000, 9999)]);

            lib_response('success', "Đăng ký thành công! Mã độc giả của bạn là: $ma_doc_gia. Bạn đã nhận bonus 500,000 ₫ vào Ví nội bộ để mượn sách!", [
                'ma_doc_gia' => $ma_doc_gia
            ]);
            break;

        // ============================================================
        // 1. DASHBOARD STATS
        // ============================================================
        case 'stats':
            $total_books = $pdo->query("SELECT SUM(so_luong) FROM books")->fetchColumn() ?: 0;
            $available_books = $pdo->query("SELECT SUM(co_san) FROM books")->fetchColumn() ?: 0;
            $total_readers = $pdo->query("SELECT COUNT(*) FROM readers")->fetchColumn() ?: 0;
            $active_borrows = $pdo->query("SELECT COUNT(*) FROM rental_orders WHERE trang_thai IN ('Đang thuê', 'Đang giao', 'Đang xử lý')")->fetchColumn() ?: 0;
            $overdue_borrows = $pdo->query("SELECT COUNT(*) FROM rental_orders WHERE trang_thai = 'Quá hạn'")->fetchColumn() ?: 0;
            $total_categories = $pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn() ?: 0;
            
            $frozen_deposit_pool = $pdo->query("SELECT SUM(tien_coc_dong_bang) FROM readers")->fetchColumn() ?: 0;
            $total_rent_revenue = $pdo->query("SELECT SUM(tong_tien_thue) FROM rental_orders WHERE trang_thai != 'Hủy'")->fetchColumn() ?: 0;
            $total_penalty_revenue = $pdo->query("SELECT SUM(tien_phat) FROM rental_orders")->fetchColumn() ?: 0;

            $physical_copies = $pdo->query("SELECT pc.*, b.ten_sach FROM physical_copies pc JOIN books b ON pc.book_id = b.id ORDER BY pc.id DESC")->fetchAll();

            lib_response('success', 'Lấy dữ liệu thống kê thành công', [
                'stats' => [
                    'total_books' => (int)$total_books,
                    'available_books' => (int)$available_books,
                    'total_readers' => (int)$total_readers,
                    'active_borrows' => (int)$active_borrows,
                    'overdue_borrows' => (int)$overdue_borrows,
                    'total_categories' => (int)$total_categories,
                    'frozen_deposit_pool' => (float)$frozen_deposit_pool,
                    'total_rent_revenue' => (float)$total_rent_revenue,
                    'total_penalty_revenue' => (float)$total_penalty_revenue
                ],
                'physical_copies' => $physical_copies,
                'team' => [
                    'leader' => 'Nguyễn Đăng Khải',
                    'members' => ['Nguyễn Nhật Linh Ân', 'Phan Duy'],
                    'project' => 'Hệ Thống Cho Thuê Sách & Truyện Tranh Enterprise 4.0',
                    'version' => '4.0 Enterprise Auth'
                ]
            ]);
            break;

        // 2. WALLET & CHECKOUT
        case 'wallet_info':
            $reader_id = (int)($data['reader_id'] ?? 1);
            $stmt = $pdo->prepare("SELECT * FROM readers WHERE id=?");
            $stmt->execute([$reader_id]);
            $reader = $stmt->fetch();

            if (!$reader) lib_response('error', 'Không tìm thấy thông tin độc giả');

            $tx_stmt = $pdo->prepare("SELECT * FROM wallet_transactions WHERE reader_id=? ORDER BY id DESC");
            $tx_stmt->execute([$reader_id]);
            $transactions = $tx_stmt->fetchAll();

            lib_response('success', 'Thông tin Ví nội bộ', [
                'wallet' => [
                    'reader_id' => $reader['id'],
                    'ho_ten' => $reader['ho_ten'],
                    'so_du_vi' => (float)$reader['so_du_vi'],
                    'tien_coc_dong_bang' => (float)$reader['tien_coc_dong_bang'],
                    'so_du_kha_dung' => (float)($reader['so_du_vi'] - $reader['tien_coc_dong_bang']),
                    'xac_minh_kyc' => $reader['xac_minh_kyc'],
                    'loai_doc_gia' => $reader['loai_doc_gia']
                ],
                'transactions' => $transactions
            ]);
            break;

        case 'wallet_topup':
            $reader_id = (int)($data['reader_id'] ?? 1);
            $so_tien = (float)($data['so_tien'] ?? 100000);

            if ($so_tien <= 0) lib_response('error', 'Số tiền nạp không hợp lệ');

            $pdo->prepare("UPDATE readers SET so_du_vi = so_du_vi + ? WHERE id=?")->execute([$so_tien, $reader_id]);
            $ma_tx = 'WT-' . rand(1000, 9999);
            $pdo->prepare("INSERT INTO wallet_transactions (reader_id, ma_giao_dich, loai_giao_dich, so_tien, mo_ta) VALUES (?, ?, 'Nạp tiền', ?, 'Nạp tiền vào Ví qua VietQR')")
                ->execute([$reader_id, $ma_tx, $so_tien]);

            lib_response('success', 'Nạp tiền vào Ví thành công! Cộng thêm ' . number_format($so_tien, 0, ',', '.') . ' ₫');
            break;

        case 'issue_borrow':
        case 'client_checkout':
            $reader_id = (int)($data['reader_id'] ?? 0);
            $book_id = (int)($data['book_id'] ?? 0);
            $ngay_bat_dau = $data['ngay_bat_dau'] ?? date('Y-m-d');
            $ngay_ket_thuc = $data['ngay_ket_thuc'] ?? date('Y-m-d', strtotime('+14 days'));
            $phuong_thuc_nhan = $data['phuong_thuc_nhan'] ?? 'Giao tận nơi';

            if (!$reader_id || !$book_id) lib_response('error', 'Vui lòng chọn Độc giả và Đầu sách mượn');

            $days = max(1, (int)((strtotime($ngay_ket_thuc) - strtotime($ngay_bat_dau)) / 86400));

            $b_stmt = $pdo->prepare("SELECT * FROM books WHERE id=?");
            $b_stmt->execute([$book_id]);
            $book = $b_stmt->fetch();

            if (!$book || $book['co_san'] <= 0) {
                lib_response('error', 'Sách/Truyện này hiện đã hết bản khả dụng trong kho!');
            }

            $copy_stmt = $pdo->prepare("SELECT * FROM physical_copies WHERE book_id=? AND trang_thai='Có sẵn' LIMIT 1");
            $copy_stmt->execute([$book_id]);
            $copy = $copy_stmt->fetch();

            if (!$copy) lib_response('error', 'Không tìm thấy bản sao vật lý còn sẵn!');

            $tong_tien_thue = $book['gia_thue_ngay'] * $days;
            $tong_tien_coc = ($book['gia_bia'] * ($book['ty_le_coc'] / 100));

            $r_stmt = $pdo->prepare("SELECT * FROM readers WHERE id=?");
            $r_stmt->execute([$reader_id]);
            $reader = $r_stmt->fetch();

            $so_du_kha_dung = $reader['so_du_vi'] - $reader['tien_coc_dong_bang'];
            $can_thanh_toan = $tong_tien_thue + $tong_tien_coc;

            if ($so_du_kha_dung < $can_thanh_toan) {
                lib_response('error', 'Số dư Ví khả dụng không đủ! Cần có tối thiểu ' . number_format($can_thanh_toan, 0, ',', '.') . ' ₫ (Tiền thuê: ' . number_format($tong_tien_thue, 0, ',', '.') . ' ₫ + Tiền cọc: ' . number_format($tong_tien_coc, 0, ',', '.') . ' ₫)');
            }

            $pdo->beginTransaction();

            $ma_don = 'RENT-' . rand(1000, 9999);
            $stmtOrder = $pdo->prepare("INSERT INTO rental_orders (ma_don, reader_id, ngay_bat_dau, ngay_ket_thuc, phuong_thuc_nhan, tong_tien_thue, tong_tien_coc, trang_thai) VALUES (?, ?, ?, ?, ?, ?, ?, 'Đang mượn')");
            $stmtOrder->execute([$ma_don, $reader_id, $ngay_bat_dau, $ngay_ket_thuc, $phuong_thuc_nhan, $tong_tien_thue, $tong_tien_coc]);
            $order_id = $pdo->lastInsertId();

            $pdo->prepare("INSERT INTO rental_order_items (order_id, physical_copy_id, tien_coc_item, tien_thue_item) VALUES (?, ?, ?, ?)")
                ->execute([$order_id, $copy['id'], $tong_tien_coc, $tong_tien_thue]);

            $pdo->prepare("UPDATE physical_copies SET trang_thai='Đang cho thuê', so_lan_thue = so_lan_thue + 1 WHERE id=?")->execute([$copy['id']]);
            $pdo->prepare("UPDATE books SET co_san = co_san - 1 WHERE id=?")->execute([$book_id]);

            $pdo->prepare("UPDATE readers SET so_du_vi = so_du_vi - ?, tien_coc_dong_bang = tien_coc_dong_bang + ? WHERE id=?")->execute([$tong_tien_thue, $tong_tien_coc, $reader_id]);

            $pdo->prepare("INSERT INTO wallet_transactions (reader_id, ma_giao_dich, loai_giao_dich, so_tien, mo_ta) VALUES (?, ?, 'Thanh toán phí thuê', ?, ?)")
                ->execute([$reader_id, 'WT-THUE-' . rand(100, 999), $tong_tien_thue, "Thanh toán phí thuê đơn $ma_don"]);

            $pdo->prepare("INSERT INTO wallet_transactions (reader_id, ma_giao_dich, loai_giao_dich, so_tien, mo_ta) VALUES (?, ?, 'Đóng băng cọc', ?, ?)")
                ->execute([$reader_id, 'WT-COC-' . rand(100, 999), $tong_tien_coc, "Đóng băng tiền cọc đơn $ma_don"]);

            $pdo->commit();

            lib_response('success', "Đặt thuê thành công! Mã đơn: $ma_don. Tiền cọc " . number_format($tong_tien_coc, 0, ',', '.') . " ₫ đã được đóng băng an toàn trong Ví.", ['ma_don' => $ma_don]);
            break;

        case 'admin_scan_checkin':
        case 'return_borrow':
            $barcode = trim($data['barcode'] ?? '');
            $order_id = (int)($data['id'] ?? $data['order_id'] ?? 0);
            $tinh_trang = $data['tinh_trang_hao_mon'] ?? $data['tinh_trang_tra'] ?? 'Bình thường';
            $tien_phat = (float)($data['tien_phat'] ?? 0);

            if ($barcode !== '') {
                $copy_stmt = $pdo->prepare("SELECT * FROM physical_copies WHERE barcode=?");
                $copy_stmt->execute([$barcode]);
                $copy = $copy_stmt->fetch();
                if (!$copy) lib_response('error', 'Không tìm thấy mã Barcode cuốn sách này!');

                $item_stmt = $pdo->prepare("SELECT roi.*, ro.reader_id, ro.ma_don, ro.tong_tien_coc, ro.trang_thai FROM rental_order_items roi JOIN rental_orders ro ON roi.order_id = ro.id WHERE roi.physical_copy_id=? AND ro.trang_thai IN ('Đang thuê', 'Đang mượn', 'Quá hạn', 'Đang trả/Kiểm duyệt') ORDER BY roi.id DESC LIMIT 1");
                $item_stmt->execute([$copy['id']]);
                $order_item = $item_stmt->fetch();

                if (!$order_item) lib_response('error', 'Cuốn sách này hiện không nằm trong đơn mượn/thuê nào cần trả!');
                $order_id = $order_item['order_id'];
            }

            $stmtOrder = $pdo->prepare("SELECT * FROM rental_orders WHERE id=?");
            $stmtOrder->execute([$order_id]);
            $order = $stmtOrder->fetch();

            if (!$order || $order['trang_thai'] === 'Hoàn tất') {
                lib_response('error', 'Đơn mượn này đã được trả và hoàn tất trước đó!');
            }

            $reader_id = $order['reader_id'];
            $tong_tien_coc = $order['tong_tien_coc'];
            $hoan_coc = max(0, $tong_tien_coc - $tien_phat);

            $pdo->beginTransaction();

            $today = date('Y-m-d');
            $pdo->prepare("UPDATE rental_orders SET ngay_tra_thuc_te=?, tien_coc_da_hoan=?, tien_phat=?, trang_thai='Hoàn tất' WHERE id=?")
                ->execute([$today, $hoan_coc, $tien_phat, $order_id]);

            $pdo->prepare("UPDATE readers SET tien_coc_dong_bang = MAX(0, tien_coc_dong_bang - ?), so_du_vi = so_du_vi + ? WHERE id=?")
                ->execute([$tong_tien_coc, $hoan_coc, $reader_id]);

            $item_query = $pdo->prepare("SELECT physical_copy_id FROM rental_order_items WHERE order_id=?");
            $item_query->execute([$order_id]);
            $items = $item_query->fetchAll();

            foreach ($items as $it) {
                $p_id = $it['physical_copy_id'];
                $pdo->prepare("UPDATE physical_copies SET trang_thai='Có sẵn', tinh_trang_hao_mon=? WHERE id=?")->execute([$tinh_trang, $p_id]);
                $b_id = $pdo->query("SELECT book_id FROM physical_copies WHERE id=$p_id")->fetchColumn();
                if ($b_id) $pdo->prepare("UPDATE books SET co_san = co_san + 1 WHERE id=?")->execute([$b_id]);
            }

            $pdo->prepare("INSERT INTO wallet_transactions (reader_id, ma_giao_dich, loai_giao_dich, so_tien, mo_ta) VALUES (?, ?, 'Hoàn tiền cọc', ?, ?)")
                ->execute([$reader_id, 'WT-REFUND-' . rand(100, 999), $hoan_coc, "Giải phóng hoàn tiền cọc cho đơn {$order['ma_don']}"]);

            $pdo->commit();

            lib_response('success', "Check-in trả sách thành công! Đã giải phóng hoàn trả " . number_format($hoan_coc, 0, ',', '.') . " ₫ tiền cọc trực tiếp vào Ví nội bộ độc giả.");
            break;

        case 'extend_borrow':
        case 'client_extend_rental':
            $id = (int)($data['id'] ?? 0);
            if (!$id) lib_response('error', 'Thiếu ID đơn thuê');

            $stmt = $pdo->prepare("SELECT * FROM rental_orders WHERE id=?");
            $stmt->execute([$id]);
            $order = $stmt->fetch();

            if (!$order || $order['trang_thai'] === 'Hoàn tất') {
                lib_response('error', 'Không thể gia hạn đơn đã hoàn tất');
            }

            if (($order['so_lan_gia_han'] ?? 0) >= 2) {
                lib_response('error', 'Đơn thuê này đã được gia hạn tối đa 2 lần!');
            }

            $new_due_date = date('Y-m-d', strtotime($order['ngay_ket_thuc'] . ' + 7 days'));
            $update = $pdo->prepare("UPDATE rental_orders SET ngay_ket_thuc=?, so_lan_gia_han = so_lan_gia_han + 1 WHERE id=?");
            $update->execute([$new_due_date, $id]);

            lib_response('success', 'Gia hạn thành công thêm 7 ngày! Hạn trả mới: ' . $new_due_date);
            break;

        case 'get_borrows':
        case 'get_orders':
            $status = trim($data['status'] ?? '');
            $search = trim($data['search'] ?? '');
            $reader_id = (int)($data['reader_id'] ?? 0);

            $sql = "SELECT ro.*, r.ho_ten as reader_name, r.ma_doc_gia, r.so_dien_thoai,
                    (SELECT b.ten_sach FROM rental_order_items roi JOIN physical_copies pc ON roi.physical_copy_id = pc.id JOIN books b ON pc.book_id = b.id WHERE roi.order_id = ro.id LIMIT 1) as ten_sach,
                    (SELECT b.hinh_anh FROM rental_order_items roi JOIN physical_copies pc ON roi.physical_copy_id = pc.id JOIN books b ON pc.book_id = b.id WHERE roi.order_id = ro.id LIMIT 1) as hinh_anh
                    FROM rental_orders ro
                    JOIN readers r ON ro.reader_id = r.id
                    WHERE 1=1";
            $params = [];

            if ($reader_id > 0) {
                $sql .= " AND ro.reader_id = ?";
                $params[] = $reader_id;
            }

            if ($status !== '') {
                $sql .= " AND ro.trang_thai = ?";
                $params[] = $status;
            }

            if ($search !== '') {
                $sql .= " AND (ro.ma_don LIKE ? OR r.ho_ten LIKE ?)";
                $like = "%$search%";
                $params[] = $like; $params[] = $like;
            }

            $sql .= " ORDER BY ro.id DESC";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $borrows = $stmt->fetchAll();

            lib_response('success', 'Danh sách đơn thuê', ['borrows' => $borrows]);
            break;

        case 'get_books':
            $search = trim($data['search'] ?? '');
            $cat_id = $data['category_id'] ?? '';

            $sql = "SELECT b.*, c.ten_danh_muc FROM books b JOIN categories c ON b.category_id = c.id WHERE 1=1";
            $params = [];

            if ($search !== '') {
                $sql .= " AND (b.ten_sach LIKE ? OR b.tac_gia LIKE ? OR b.ma_sach LIKE ?)";
                $like = "%$search%";
                $params[] = $like; $params[] = $like; $params[] = $like;
            }

            if ($cat_id !== '') {
                $sql .= " AND b.category_id = ?";
                $params[] = $cat_id;
            }

            $sql .= " ORDER BY b.id DESC";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $books = $stmt->fetchAll();
            lib_response('success', 'Danh sách sách', ['books' => $books]);
            break;

        case 'get_categories':
            $stmt = $pdo->query("SELECT c.*, COUNT(b.id) as total_books FROM categories c LEFT JOIN books b ON c.id = b.category_id GROUP BY c.id ORDER BY c.id ASC");
            lib_response('success', 'Danh mục', ['categories' => $stmt->fetchAll()]);
            break;

        case 'get_readers':
            $stmt = $pdo->query("SELECT * FROM readers ORDER BY id DESC");
            lib_response('success', 'Độc giả', ['readers' => $stmt->fetchAll()]);
            break;

        case 'cron_run_overdue_scan':
            $today = date('Y-m-d');
            $stmt = $pdo->prepare("SELECT * FROM rental_orders WHERE ngay_ket_thuc < ? AND trang_thai IN ('Đang mượn', 'Đang thuê')");
            $stmt->execute([$today]);
            $overdue_orders = $stmt->fetchAll();

            $count = 0;
            foreach ($overdue_orders as $ord) {
                $late_days = (int)((strtotime($today) - strtotime($ord['ngay_ket_thuc'])) / 86400);
                $late_fine = $late_days * 5000;

                $pdo->prepare("UPDATE rental_orders SET tien_phat=?, trang_thai='Quá hạn' WHERE id=?")
                    ->execute([$late_fine, $ord['id']]);
                $count++;
            }

            lib_response('success', "Chạy Cron Job tự động thành công! Đã quét và cập nhật $count đơn quá hạn.");
            break;

        // ============================================================
        // H. PHÂN HỆ DỊCH VỤ VẼ MANGA FREELANCER (FASTLANCE STYLE)
        // ============================================================
        case 'get_manga_services':
            $search = trim($data['search'] ?? '');
            $category = trim($data['category'] ?? '');

            $sql = "SELECT * FROM manga_services WHERE 1=1";
            $params = [];

            if ($search !== '') {
                $sql .= " AND (title LIKE ? OR freelancer_name LIKE ? OR description LIKE ?)";
                $like = "%$search%";
                $params[] = $like; $params[] = $like; $params[] = $like;
            }

            if ($category !== '' && $category !== 'Tất cả') {
                $sql .= " AND category_tag = ?";
                $params[] = $category;
            }

            $sql .= " ORDER BY id DESC";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $services = $stmt->fetchAll();

            lib_response('success', 'Danh sách dịch vụ vẽ Manga', ['services' => $services]);
            break;

        case 'order_manga_service':
            $reader_id = (int)($data['reader_id'] ?? 1);
            $service_id = (int)($data['service_id'] ?? 0);
            $package_tier = trim($data['package_tier'] ?? 'Gói Tiêu Chuẩn');
            $note = trim($data['note'] ?? 'Vẽ truyện tranh theo yêu cầu');

            if (!$service_id) {
                lib_response('error', 'Vui lòng chọn dịch vụ vẽ Manga!');
            }

            $stmt_serv = $pdo->prepare("SELECT * FROM manga_services WHERE id=?");
            $stmt_serv->execute([$service_id]);
            $service = $stmt_serv->fetch();

            if (!$service) {
                lib_response('error', 'Dịch vụ vẽ Manga không tồn tại');
            }

            $price = $service['price_standard'];
            if ($package_tier === 'Gói Cơ Bản') $price = $service['price_basic'];
            if ($package_tier === 'Gói Cao Cấp') $price = $service['price_premium'];

            // Check reader wallet balance
            $stmt_r = $pdo->prepare("SELECT * FROM readers WHERE id=?");
            $stmt_r->execute([$reader_id]);
            $reader = $stmt_r->fetch();

            if (!$reader) {
                lib_response('error', 'Tài khoản người dùng không tồn tại');
            }

            if ($reader['so_du_vi'] < $price) {
                lib_response('error', 'Số dư ví không đủ! Cần ' . number_format($price) . ' VNĐ. Vui lòng nạp thêm tiền vào ví.');
            }

            $pdo->beginTransaction();
            try {
                // Deduct wallet balance
                $new_balance = $reader['so_du_vi'] - $price;
                $pdo->prepare("UPDATE readers SET so_du_vi=? WHERE id=?")->execute([$new_balance, $reader_id]);

                // Record transaction
                $ma_gd = 'WT-DRAW-' . time() . '-' . rand(10,99);
                $pdo->prepare("INSERT INTO wallet_transactions (reader_id, ma_giao_dich, loai_giao_dich, so_tien, mo_ta) VALUES (?, ?, 'Thanh toán dịch vụ vẽ', ?, ?)")
                    ->execute([$reader_id, $ma_gd, $price, "Thanh toán $package_tier dịch vụ: " . $service['title']]);

                // Create service order
                $ma_don_ve = 'DRAW-' . rand(1000, 9999);
                $pdo->prepare("INSERT INTO manga_service_orders (ma_don_ve, reader_id, service_id, package_tier, so_tien, yeu_cau_chi_tiet, trang_thai) VALUES (?, ?, ?, ?, ?, ?, 'Đang thực hiện')")
                    ->execute([$ma_don_ve, $reader_id, $service_id, $package_tier, $price, $note]);

                $pdo->commit();
                lib_response('success', "Đặt vẽ Manga thành công! Mã đơn: $ma_don_ve. Họa sĩ sẽ liên hệ trò chuyện với bạn ngay.", [
                    'ma_don_ve' => $ma_don_ve,
                    'so_du_vi' => $new_balance
                ]);
            } catch (Exception $ex) {
                $pdo->rollBack();
                lib_response('error', 'Lỗi thanh toán dịch vụ vẽ: ' . $ex->getMessage());
            }
            break;

        case 'create_manga_service':
            $freelancer_name = trim($data['freelancer_name'] ?? '');
            $title = trim($data['title'] ?? '');
            $category_tag = trim($data['category_tag'] ?? 'Vẽ Manga');
            $price_basic = (float)($data['price_basic'] ?? 150000);
            $price_standard = (float)($data['price_standard'] ?? 350000);
            $price_premium = (float)($data['price_premium'] ?? 800000);
            $description = trim($data['description'] ?? '');
            $portfolio_image = trim($data['portfolio_image'] ?? 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=600');
            $freelancer_avatar = trim($data['freelancer_avatar'] ?? 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150');

            if (!$freelancer_name || !$title) {
                lib_response('error', 'Vui lòng điền đầy đủ Tên Họa sĩ và Tiêu đề dịch vụ vẽ!');
            }

            $pdo->prepare("INSERT INTO manga_services (freelancer_name, freelancer_avatar, freelancer_badge, rating_score, review_count, title, category_tag, portfolio_image, delivery_days, starting_price, price_basic, price_standard, price_premium, description) VALUES (?, ?, 'Verified Pro', 5.0, 1, ?, ?, ?, 2, ?, ?, ?, ?, ?)")
                ->execute([$freelancer_name, $freelancer_avatar, $title, $category_tag, $portfolio_image, $price_basic, $price_basic, $price_standard, $price_premium, $description]);

            lib_response('success', 'Đăng dịch vụ vẽ Manga thành công! Dịch vụ đã xuất hiện trên sàn Fastlance.');
            break;

        case 'get_manga_orders':
            $reader_id = (int)($data['reader_id'] ?? 0);
            $sql = "SELECT o.*, s.title as service_title, s.freelancer_name, s.freelancer_avatar FROM manga_service_orders o JOIN manga_services s ON o.service_id = s.id";
            $params = [];
            if ($reader_id > 0) {
                $sql .= " WHERE o.reader_id = ?";
                $params[] = $reader_id;
            }
            $sql .= " ORDER BY o.id DESC";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            lib_response('success', 'Danh sách đơn đặt vẽ', ['manga_orders' => $stmt->fetchAll()]);
            break;

        default:
            lib_response('error', 'Hành động không hợp lệ: ' . $action);
            break;
    }
} catch (Exception $e) {
    lib_response('error', 'Lỗi Server API: ' . $e->getMessage());
}
