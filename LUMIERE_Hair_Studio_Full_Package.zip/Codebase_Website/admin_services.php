<?php
// admin_services.php - Trang 3: Quản Lý Danh Mục Dịch Vụ Salon
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/admin_nav.php';

$db = get_db();
$services = $db['services'] ?? [];
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>LUMIÈRE Admin - Quản Lý Danh Mục Dịch Vụ</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: { salon: { primary: '#4A6B5D', secondary: '#C89F82' } }
        }
      }
    }
  </script>
</head>
<body class="bg-[#F8F6F0] min-h-screen text-stone-900 flex">

  <!-- TOAST NOTIFICATION -->
  <div id="toast" class="hidden fixed top-5 right-5 z-50 bg-stone-900 text-stone-100 px-5 py-3 rounded-2xl shadow-2xl text-xs font-medium items-center gap-2 animate-bounce">
    <span>⚡</span>
    <span id="toastMsg">Thông báo</span>
  </div>

  <!-- SIDEBAR NAV -->
  <?php render_admin_nav('services'); ?>

  <!-- MAIN CONTENT AREA -->
  <div class="flex-1 flex flex-col min-w-0">
    <header class="bg-white border-b border-stone-200 px-8 py-5 flex justify-between items-center">
      <div>
        <h2 class="font-serif text-2xl font-bold text-stone-900">Quản Lý Danh Mục Dịch Vụ Salon</h2>
        <p class="text-xs text-stone-500">Thêm gói dịch vụ mới hoặc chỉnh sửa giá tiền & mô tả</p>
      </div>
      <button onclick="openAddServiceModal()" class="px-5 py-2.5 rounded-2xl bg-[#4A6B5D] hover:bg-stone-900 text-white text-xs font-bold shadow-md transition">
        + Thêm Dịch Vụ Mới
      </button>
    </header>

    <main class="p-8 space-y-6 flex-1 overflow-y-auto">
      
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php foreach ($services as $svc): ?>
          <div class="bg-white rounded-3xl border border-stone-200 shadow-sm p-5 flex flex-col justify-between space-y-4">
            <div class="flex items-start gap-4">
              <img src="<?= htmlspecialchars($svc['image']) ?>" class="w-16 h-16 rounded-2xl object-cover border" onerror="this.onerror=null; this.src='https://images.unsplash.com/photo-1562322140-8baeececf3df?auto=format&fit=crop&q=80&w=600';" />
              <div class="space-y-1">
                <span class="text-[10px] bg-stone-100 px-2 py-0.5 rounded-full font-bold text-stone-600"><?= htmlspecialchars($svc['category'] ?? 'Dịch vụ') ?></span>
                <h3 class="font-bold text-sm text-stone-900"><?= htmlspecialchars($svc['name']) ?></h3>
                <p class="text-xs font-bold text-[#4A6B5D]"><?= format_vnd($svc['price']) ?></p>
              </div>
            </div>
            <p class="text-xs text-stone-500 line-clamp-2 leading-relaxed"><?= htmlspecialchars($svc['description']) ?></p>
            <div class="pt-3 border-t border-stone-100 flex justify-between items-center text-xs">
              <span class="text-stone-400">⏱️ <?= htmlspecialchars($svc['duration']) ?></span>
              <button onclick="deleteService('<?= htmlspecialchars($svc['id']) ?>')" class="text-rose-600 font-bold hover:underline">Xóa Dịch Vụ</button>
            </div>
          </div>
        <?php endforeach; ?>
      </div>

    </main>
  </div>

  <!-- ADD SERVICE MODAL -->
  <div id="addServiceModal" class="hidden fixed inset-0 z-50 bg-stone-950/60 backdrop-blur-sm flex items-center justify-center p-4">
    <div class="bg-white rounded-3xl p-6 max-w-md w-full space-y-4">
      <h3 class="font-serif text-lg font-bold text-stone-900">Thêm Dịch Vụ Mới Vào MySQL</h3>
      <form onsubmit="submitAddService(event)" class="space-y-3">
        <div>
          <label class="block text-xs font-bold text-stone-700 mb-1">Tên Dịch Vụ</label>
          <input type="text" id="svcName" required placeholder="Uốn Phồng Chân Tóc" class="w-full px-4 py-2.5 rounded-xl border text-xs focus:outline-none focus:ring-2 focus:ring-[#4A6B5D]" />
        </div>
        <div>
          <label class="block text-xs font-bold text-stone-700 mb-1">Giá Dịch Vụ (VND)</label>
          <input type="number" id="svcPrice" required placeholder="350000" class="w-full px-4 py-2.5 rounded-xl border text-xs focus:outline-none focus:ring-2 focus:ring-[#4A6B5D]" />
        </div>
        <div>
          <label class="block text-xs font-bold text-stone-700 mb-1">Thời gian thực hiện</label>
          <input type="text" id="svcDuration" value="45 phút" class="w-full px-4 py-2.5 rounded-xl border text-xs focus:outline-none focus:ring-2 focus:ring-[#4A6B5D]" />
        </div>
        <div class="flex gap-2 pt-2">
          <button type="button" onclick="closeAddServiceModal()" class="flex-1 py-2.5 rounded-xl border text-xs font-bold">Hủy</button>
          <button type="submit" class="flex-1 py-2.5 rounded-xl bg-[#4A6B5D] text-white text-xs font-bold">Lưu Dịch Vụ</button>
        </div>
      </form>
    </div>
  </div>

  <script>
    function showToast(msg) {
      const toast = document.getElementById('toast');
      document.getElementById('toastMsg').innerText = msg;
      toast.classList.remove('hidden');
      toast.classList.add('flex');
      setTimeout(() => toast.classList.add('hidden'), 3000);
    }

    function openAddServiceModal() { document.getElementById('addServiceModal').classList.remove('hidden'); }
    function closeAddServiceModal() { document.getElementById('addServiceModal').classList.add('hidden'); }

    function submitAddService(e) {
      e.preventDefault();
      const name = document.getElementById('svcName').value;
      const price = document.getElementById('svcPrice').value;
      const duration = document.getElementById('svcDuration').value;

      const formData = new FormData();
      formData.append('action', 'add_service');
      formData.append('name', name);
      formData.append('price', price);
      formData.append('duration', duration);

      fetch('api.php', { method: 'POST', body: formData })
      .then(res => res.json())
      .then(data => {
        closeAddServiceModal();
        showToast(data.message);
        setTimeout(() => location.reload(), 1000);
      });
    }

    function deleteService(id) {
      if (!confirm('Bạn có chắc muốn xóa dịch vụ này?')) return;
      const formData = new FormData();
      formData.append('action', 'delete_service');
      formData.append('id', id);

      fetch('api.php', { method: 'POST', body: formData })
      .then(res => res.json())
      .then(data => {
        showToast(data.message);
        setTimeout(() => location.reload(), 1000);
      });
    }

    function logoutAdmin() {
      fetch('api.php?action=logout').then(() => location.href = 'login.php?tab=admin');
    }
  </script>
</body>
</html>
