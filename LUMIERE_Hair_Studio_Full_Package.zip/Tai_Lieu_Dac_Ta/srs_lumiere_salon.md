# TÀI LIỆU ĐẶC TẢ YÊU CẦU PHẦN MỀM (SOFTWARE REQUIREMENTS SPECIFICATION - SRS)
## DỰ ÁN: HỆ THỐNG ĐẶT LỊCH SALON TÓC LUMIÈRE (LUMIÈRE HAIR STUDIO)

---

## TABLE OF CONTENTS (MỤC LỤC)

1. **Introduction (Giới thiệu)**
   - 1.1 Purpose (Mục đích)
   - 1.2 Document Conventions (Quy ước tài liệu)
   - 1.3 Project Scope (Phạm vi dự án)
   - 1.4 References (Tài liệu tham khảo)
2. **System Description (Mô tả hệ thống)**
   - 2.1 Overview (Tổng quan)
   - 2.2 User Classes and Characteristics (Phân loại người dùng)
   - 2.3 Operating Environment (Môi trường vận hành)
   - 2.4 Design and Implementation Constraints (Ràng buộc thiết kế & cài đặt)
3. **Functional Requirements (Yêu cầu chức năng)**
   - 3.1 System Features (Các tính năng hệ thống)
     - 3.1.1 Quy trình Đặt lịch 5 bước & Anti Double-Booking
     - 3.1.2 Thuật toán Hoa hồng Ma trận & Báo cáo Lương
     - 3.1.3 Chuyển ca khẩn cấp & Gửi log thông báo tự động (SMS/Email)
     - 3.1.4 Cổng thông tin cá nhân dành cho Stylist
     - 3.1.5 Trung tâm Live Chat thời gian thực
   - 3.2 Use Cases (Trường hợp sử dụng)
     - 3.2.1 Overall Use Case Diagram (Sơ đồ Use Case tổng quan)
     - 3.2.2 Use Case 1: UC-06 - Đặt lịch làm tóc trực tuyến & Tính đặt cọc
     - 3.2.3 Use Case 2: UC-10 - Quản lý, Duyệt lịch hẹn & Chuyển ca khẩn cấp
     - 3.2.4 Use Case 3: UC-14 - Thuật toán hoa hồng ma trận & Xuất báo cáo lương
   - 3.3 Entity Relationship Diagrams (Sơ đồ quan hệ thực thể - ERD)
   - 3.4 Data Dictionary (Từ điển dữ liệu)
     - 3.4.1 Entity `services` (Dịch vụ Salon)
     - 3.4.2 Entity `stylists` (Đội ngũ Thợ)
     - 3.4.3 Entity `appointments` (Đơn đặt lịch hẹn)
     - 3.4.4 Entity `users` (Người dùng & Khách hàng)
     - 3.4.5 Entity `chat_messages` (Tin nhắn Live Chat)
     - 3.4.6 Entity `notification_logs` (Nhật ký thông báo)
4. **External Interface Requirements (Yêu cầu giao diện bên ngoài)**
   - 4.1 User Interfaces (Giao diện người dùng)
   - 4.2 Hardware Interfaces (Giao diện phần cứng)
   - 4.3 Software Interfaces (Giao diện phần mềm)
   - 4.4 Communications Interfaces (Giao diện truyền thông)
5. **Technical Requirements (Non functional) (Yêu cầu kỹ thuật phi chức năng)**
   - 5.1 Performance (Hiệu năng)
   - 5.2 Scalability (Khả năng mở rộng)
   - 5.3 Security (Bảo mật)
   - 5.4 Maintainability (Khả năng bảo trì)
   - 5.5 Usability (Tính dễ sử dụng)
   - 5.6 Multi-lingual Support (Hỗ trợ đa ngôn ngữ)
   - 5.7 Auditing and Logging (Kiểm toán & Ghi log)
   - 5.8 Availability (Độ khả dụng)
6. **Open Issues (Vấn đề mở & Phát triển tương lai)**

---

## 1. INTRODUCTION (GIỚI THIỆU)

### 1.1 Purpose (Mục đích)
Tài liệu Đặc tả Yêu cầu Phần mềm (SRS) này mô tả toàn bộ chi tiết yêu cầu kỹ thuật, kiến trúc chức năng, sơ đồ Use Case, mô hình CSDL ERD và quy tắc vận hành cho website **LUMIÈRE Hair Studio**. Tài liệu đóng vai trò là căn cứ chuẩn cho đội ngũ phát triển, kiểm thử (QA/QC), quản lý dự án và khách hàng nghiệm thu sản phẩm.

### 1.2 Document Conventions (Quy ước tài liệu)
- **Bold / Viết hoa**: Nhấn mạnh thuật ngữ kỹ thuật, tên Use Case, tên bảng CSDL.
- **`Code font`**: Tên trường dữ liệu, endpoint API, đường dẫn tệp mã nguồn.
- **Alert Notes**: 
  > [!IMPORTANT]
  > Tất cả các quy tắc đặt cọc 20%, chống trùng ca (Anti Double-Booking), phân bổ hoa hồng ma trận và chuyển ca khẩn cấp phải tuân thủ nghiêm ngặt chuẩn ràng buộc dữ liệu MySQL PDO.

### 1.3 Project Scope (Phạm vi dự án)
Hệ thống LUMIÈRE Hair Studio bao gồm các phân hệ:
1. **Phân hệ Khách hàng (Client Portal)**: Tra cứu dịch vụ, mẫu tóc layer/bob/undercut, chọn màu nhuộm trà sữa/nâu lạnh/balayage, chọn stylist & khung giờ trống, thực hiện đặt lịch 5 bước, tính cọc 20%, hủy lịch hoàn tiền tự động và Live Chat.
2. **Phân hệ Quản trị (Admin Portal)**: Dashboard tổng quan, quản lý lịch hẹn động, trung tâm Chat 2 chiều, quản lý catalog dịch vụ/thợ, xử lý sự cố chuyển ca khẩn cấp (Emergency Reassignment) + tự động gửi log SMS/Email, báo cáo lương & hoa hồng ma trận theo tháng.
3. **Phân hệ Thợ (Stylist Portal)**: Đăng nhập cá nhân, theo dõi lịch làm việc ngày, cập nhật tiến độ nghiệm thu ca hẹn, tính toán hoa hồng ma trận (Master/Senior/Junior x loại dịch vụ) và thu nhập lương cứng.

### 1.4 References (Tài liệu tham khảo)
- Chuẩn IEEE 830-1998 cho tài liệu SRS.
- Hồ sơ thiết kế cơ sở dữ liệu `lumiere_salon` qua MySQL phpMyAdmin Designer.
- Ngôn ngữ lập trình PHP 8.x PDO, MySQL 8.0, HTML5/Tailwind CSS JavaScript (ES6 AJAX).

---

## 2. SYSTEM DESCRIPTION (MÔ TẢ HỆ THỐNG)

### 2.1 Overview (Tổng quan)
Hệ thống LUMIÈRE Hair Studio là ứng dụng Web đa phân hệ hiện đại, giúp số hóa quy trình vận hành salon tóc từ khâu tiếp nhận đặt lịch trực tuyến của khách hàng đến khâu phân ca, chuyển đổi trạng thái động và thanh toán/tính hoa hồng cho nhân sự thợ cắt tóc.

### 2.2 User Classes and Characteristics (Phân loại người dùng)

| Nhóm người dùng | Mô tả & Quyền hạn |
| :--- | :--- |
| **Khách hàng (Customer)** | Khách truy cập web hoặc người dùng đăng ký: Đặt lịch 5 bước, xem catalogue, Live Chat, gửi đánh giá 5 sao, xem và hủy ca hẹn với chính sách cọc. |
| **Quản trị viên (Admin)** | Quyền tối cao: Xem dashboard doanh thu, duyệt/hủy/chuyển ca hẹn, chuyển ca khẩn cấp hàng loạt khi thợ nghỉ, quản lý catalog dịch vụ/thợ, quản lý Live Chat và xuất Báo cáo lương CSV cuối tháng. |
| **Thợ cắt tóc (Stylist)** | Nhân sự chuyên môn (Master/Senior/Junior): Đăng nhập cổng cá nhân, xem ca hẹn trong ngày, chuyển trạng thái nghiệm thu `Completed`, theo dõi thu nhập lương cứng + hoa hồng cá nhân. |

### 2.3 Operating Environment (Môi trường vận hành)
- **Web Server**: Apache / Nginx chạy PHP 8.x trên OS Windows / Linux.
- **Database Engine**: MySQL 8.0 / MariaDB (Hỗ trợ InnoDB Engine, Foreign Key constraints `ON DELETE CASCADE / SET NULL`).
- **Trình duyệt Client**: Google Chrome, Mozilla Firefox, Apple Safari, Microsoft Edge trên Desktop & Mobile.

### 2.4 Design and Implementation Constraints (Ràng buộc thiết kế & cài đặt)
- Giao diện thiết kế chuẩn màu Pastel Salon (`#FBF9F5`, `#4A6B5D`, `#C89F82`).
- Quy trình đặt lịch ở cuối trang `index.php` trải qua 5 bước liền mạch.
- Sử dụng PHP PDO giúp ngăn chặn 100% các lỗ hổng SQL Injection.
- Mã nguồn giữ nguyên kiến trúc mô-đun không phá vỡ cấu trúc khoá ngoại CSDL.

---

## 3. FUNCTIONAL REQUIREMENTS (YÊU CẦU CHỨC NĂNG)

### 3.1 System Features (Các tính năng hệ thống)

#### 3.1.1 Quy trình Đặt lịch 5 bước & Thuật toán Anti Double-Booking
- **5 Bước Đặt Lịch**: 
  - Bước 1: Chọn gói Dịch vụ (Cắt, Uốn, Nhuộm, Keratin, Head Spa).
  - Bước 2: Chọn Mẫu Tóc & Màu Nhuộm thời trang.
  - Bước 3: Chọn Stylist yêu thích & Ngày/Khung giờ hẹn.
  - Bước 4: Nhập thông tin cá nhân & Tính tiền đặt cọc giữ chỗ 20%.
  - Bước 5: Xác nhận mã đơn & Theo dõi trạng thái ca hẹn.
- **Thuật toán Khóa Khung Giờ Động (Anti Double-Booking)**: Nội suy tổng số phút thực hiện (`minutes`) của toàn bộ dịch vụ trong ca hẹn. Khi thợ đã có ca trong khoảng $[T_{start}, T_{start} + Duration]$, hệ thống tự động ẩn hoặc vô hiệu hóa khung giờ đó trên giao diện thời gian thực.

#### 3.1.2 Thuật toán Hoa hồng Ma trận & Báo cáo Lương Cuối Tháng
- **Ma trận % Hoa hồng**:
  - **Uốn & Nhuộm (Chemical)**: Master **20%** | Senior **15%** | Junior **10%**
  - **Cắt & Tạo Kiểu (Cut/Style)**: Master **15%** | Senior **12%** | Junior **8%**
  - **Chăm Sóc & Phục Hồi (Treatment/Spa)**: Master **12%** | Senior **10%** | Junior **8%**
- **Xuất Báo Cáo Lương (`admin_salary.php`)**: Lọc theo tháng/năm, tính tổng lương cứng + hoa hồng ma trận, hỗ trợ mở modal bảng kê chi tiết từng đơn hàng, xuất file CSV (Excel) UTF-8 BOM và in phiếu lương.

#### 3.1.3 Chuyển ca khẩn cấp & Gửi log thông báo tự động (SMS/Email)
- Khi có sự cố thợ nghỉ đột xuất (`admin_stylists.php`), Admin chọn thợ nghỉ và thợ thay thế có tay nghề tương đương. Hệ thống tự động chuyển hàng loạt tất cả các ca hẹn bận sang thợ mới, đồng thời ghi nhận log nhắn tin tự động gửi SMS/Email cho khách hàng.

#### 3.1.4 Cổng thông tin cá nhân dành cho Stylist (`stylist_dashboard.php`)
- Stylist đăng nhập xem danh sách ca làm việc theo ngày, cập nhật trạng thái làm việc (`Pending` $\rightarrow$ `Confirmed` $\rightarrow$ `InProgress` $\rightarrow$ `Completed`), theo dõi số ca hoàn thành và thu nhập dự kiến (Lương cứng + Hoa hồng ma trận).

#### 3.1.5 Trung tâm Live Chat thời gian thực
- Khách hàng trò chuyện trực tiếp qua Widget góc màn hình ở trang `index.php`. Admin phản hồi đa luồng tại `admin_chat.php` qua cơ chế AJAX Polling.

---

### 3.2 Use Cases (Trường hợp sử dụng)

#### 3.2.1 Overall Use Case Diagram (Sơ đồ Use Case tổng quan)
Sơ đồ Use Case tổng quan của hệ thống LUMIÈRE Hair Studio được xây dựng dựa trên thiết kế chuẩn:

```mermaid
usecaseDiagram
    actor "Khách Hàng (Customer)" as Customer
    actor "Quản Trị Viên (Admin)" as Admin
    actor "Hệ Thống CSDL (MySQL DB)" as DB

    package "HỆ THỐNG ĐẶT LỊCH SALON TÓC LUMIÈRE" {
        package "Phân Hệ Khách Hàng" {
            usecase "UC-01: Đăng ký tài khoản" as UC01
            usecase "UC-02: Đăng nhập Khách hàng" as UC02
            usecase "UC-03: Xem Catalogue Dịch vụ & Giá" as UC03
            usecase "UC-04: Xem Mẫu tóc & Màu nhuộm" as UC04
            usecase "UC-05: Chọn Stylist & Giờ hẹn" as UC05
            usecase "UC-06: Đặt lịch làm tóc trực tuyến" as UC06
            usecase "UC-07: Gửi đánh giá 5 sao" as UC07
        }

        package "Phân Hệ Quản Trị Salon" {
            usecase "UC-08: Đăng nhập Quản trị viên" as UC08
            usecase "UC-09: Xem Thống kê Doanh thu & Đơn" as UC09
            usecase "UC-10: Quản lý & Duyệt Lịch hẹn" as UC10
            usecase "UC-11: Quản lý Dịch vụ (Thêm/Xóa)" as UC11
            usecase "UC-12: Quản lý Đội ngũ Stylist" as UC12
            usecase "UC-13: Đăng xuất hệ thống" as UC13
            usecase "UC-14: Báo cáo Lương & Hoa hồng" as UC14
        }
    }

    Customer --> UC01
    Customer --> UC02
    Customer --> UC03
    Customer --> UC04
    Customer --> UC05
    Customer --> UC06
    Customer --> UC07

    UC06 .> UC03 : <<include>>
    UC06 .> UC05 : <<include>>
    UC06 .> UC02 : <<extend>>

    Admin --> UC08
    Admin --> UC09
    Admin --> UC10
    Admin --> UC11
    Admin --> UC12
    Admin --> UC13
    Admin --> UC14

    UC10 .> UC08 : <<include>>
    UC11 .> UC08 : <<include>>
    UC12 .> UC08 : <<include>>
    UC14 .> UC08 : <<include>>

    UC06 --> DB : <<INSERT appointments>>
    UC10 --> DB : <<UPDATE status>>
    UC11 --> DB : <<INSERT/DELETE services>>
```

#### 3.2.2 Use Case 1: UC-06 - Đặt lịch làm tóc trực tuyến & Tính đặt cọc
- **Tên Use Case**: Đặt lịch làm tóc trực tuyến (Online Hair Appointment Booking).
- **Actor chính**: Khách hàng (Customer).
- **Mục đích**: Giúp khách hàng chọn dịch vụ, màu nhuộm, thợ cắt tóc và khung giờ trống khả dụng để đặt lịch giữ chỗ trực tuyến.
- **Tiền điều kiện**: Khách hàng truy cập vào giao diện web `index.php`.
- **Hậu điều kiện**: Đơn đặt lịch được lưu vào bảng `appointments` với trạng thái `Pending` và lưu giá trị cọc `depositAmount = 20% * totalPrice`.
- **Luồng sự kiện chính (Main Flow)**:
  1. Khách hàng cuộn tới Wizard 5 bước ở cuối trang.
  2. Hệ thống hiển thị danh sách Dịch vụ và giá tiền (Bước 1). Khách chọn 1 hoặc nhiều dịch vụ.
  3. Khách chọn Mẫu tóc và Màu nhuộm thời trang (Bước 2).
  4. Khách chọn Stylist và Ngày hẹn. Hệ thống gọi API `get_available_slots` quét lịch bận thực tế để trả về danh sách khung giờ trống (Bước 3).
  5. Khách nhập Tên và Số điện thoại liên hệ (Bước 4). Hệ thống tính toán tổng tiền và khoản đặt cọc 20%.
  6. Khách hàng nhấn "Xác Nhận Đặt Lịch".
  7. Hệ thống tạo mã đơn `LUMI-xxxx`, lưu vào MySQL DB và hiển thị màn hình hoàn tất thành công (Bước 5).

#### 3.2.3 Use Case 2: UC-10 - Quản lý, Duyệt lịch hẹn & Chuyển ca khẩn cấp
- **Tên Use Case**: Quản lý Lịch hẹn & Điều chuyển ca khẩn cấp.
- **Actor chính**: Quản trị viên (Admin).
- **Mục đích**: Duyệt/hủy đơn hẹn, cập nhật tiến độ, và xử lý điều chuyển ca hàng loạt khi thợ xin nghỉ đột xuất.
- **Luồng sự kiện chính (Main Flow)**:
  1. Admin đăng nhập vào `admin_appointments.php` hoặc `admin_stylists.php`.
  2. Để duyệt lịch: Admin chọn trạng thái mới (`Confirmed`, `InProgress`, `Completed`, `Cancelled`) trên danh sách đơn.
  3. Để chuyển ca khẩn cấp: Admin mở Modal "🚨 Báo Thợ Nghỉ & Chuyển Ca Khẩn Cấp".
  4. Admin chọn Thợ nghỉ (`from_stylist`) và Thợ thay thế (`to_stylist`).
  5. Hệ thống lọc tất cả ca hẹn bị ảnh hưởng, cập nhật `stylist = to_stylist` trong MySQL DB, đồng thời tạo log nhắn tin tự động trong `notification_logs`.

#### 3.2.4 Use Case 3: UC-14 - Thuật toán hoa hồng ma trận & Xuất báo cáo lương
- **Tên Use Case**: Báo cáo Lương Cuối Tháng & Phân bổ Hoa hồng Thợ.
- **Actor chính**: Quản trị viên (Admin).
- **Mục đích**: Tự động tính toán tổng thu nhập cho nhân sự thợ (Lương cứng + Hoa hồng ma trận) và hỗ trợ xuất báo cáo tài chính salon.
- **Luồng sự kiện chính (Main Flow)**:
  1. Admin truy cập trang `admin_salary.php`.
  2. Admin chọn kỳ báo cáo Tháng/Năm (mặc định là Tháng hiện tại).
  3. Hệ thống chạy hàm `get_monthly_salary_report()` bóc tách tất cả đơn hẹn `Completed` trong tháng của từng thợ.
  4. Với mỗi ca hẹn, hệ thống tính hoa hồng ma trận dựa trên cấp bậc thợ và loại dịch vụ thực hiện.
  5. Bảng thống kê hiển thị rõ Lương cơ bản, Số ca hoàn thành, Doanh thu tạo ra, Hoa hồng nhận được và Tổng thực nhận.
  6. Admin có thể nhấn "🔍 Xem Bảng Kê" để xem chi tiết từng đơn, "📥 Xuất CSV (Excel)" để tải file `.csv` UTF-8 BOM, hoặc "🖨️ In Phiếu Lương" để in trực tiếp.

---

### 3.3 Entity Relationship Diagrams (Sơ đồ quan hệ thực thể - ERD)

```mermaid
erDiagram
    users ||--o{ appointments : "places (fk_appointment_user)"
    stylists ||--o{ appointments : "assigned_to (fk_appointment_stylist)"
    hairstyles ||--o{ appointments : "selects_style (fk_appointment_hairstyle)"
    haircolors ||--o{ appointments : "selects_color (fk_appointment_haircolor)"
    users ||--o{ chat_messages : "sends_chat (fk_chat_user)"
    appointments ||--o{ notification_logs : "triggers_log (fk_notif_app)"

    users {
        int id PK
        string name
        string phone UK
        string password
        string email
        string role
    }

    stylists {
        string id PK
        string name UK
        string role
        string level
        int baseSalary
        string experience
        float rating
        int reviews
        text avatar
        text specialty
        int isAny
    }

    services {
        string id PK
        string name
        string category
        string duration
        int minutes
        int price
        text description
        string badge
        text image
    }

    hairstyles {
        string id PK
        string name UK
        string category
        text image
        string tag
        text desc
    }

    haircolors {
        string id PK
        string name UK
        string hex
        string badge
        text desc
        text image
    }

    appointments {
        string id PK
        string customerName
        string phone FK
        text services
        string hairstyle FK
        string haircolor FK
        string stylist FK
        string date
        string time
        int totalPrice
        int depositAmount
        string depositStatus
        int refundAmount
        text cancelReason
        string status
        string createdTime
        string paymentMethod
    }

    chat_messages {
        int id PK
        string customer_phone FK
        string customer_name
        enum sender
        text message
        datetime created_at
        tinyint is_read
    }

    notification_logs {
        int id PK
        string appointment_id FK
        string customer_phone
        string customer_name
        string channel
        text message
        datetime sent_at
    }
```

---

### 3.4 Data Dictionary (Từ điển dữ liệu)

#### 3.4.1 Entity `services` (Dịch vụ Salon)
| Tên Trường (Field) | Kiểu dữ liệu | Ràng buộc | Mô tả giải thích |
| :--- | :--- | :--- | :--- |
| `id` | VARCHAR(50) | PRIMARY KEY | Mã định danh dịch vụ (vd: `cut-women`, `perm-korean`) |
| `name` | VARCHAR(255) | NOT NULL | Tên dịch vụ hiển thị (vd: Cắt & Tạo Kiểu Nữ) |
| `category` | VARCHAR(100) | NULL | Phân loại (Cắt & Tạo Kiểu, Uốn & Nhuộm, Chăm Sóc & Phục Hồi) |
| `duration` | VARCHAR(50) | NULL | Chuỗi thời lượng hiển thị (vd: 45 phút, 120 phút) |
| `minutes` | INT | DEFAULT 45 | Thời lượng tính theo phút phục vụ cho thuật toán Anti Double-Booking |
| `price` | INT | NOT NULL | Giá tiền gốc niêm yết (VND) |

#### 3.4.2 Entity `stylists` (Đội ngũ Thợ)
| Tên Trường (Field) | Kiểu dữ liệu | Ràng buộc | Mô tả giải thích |
| :--- | :--- | :--- | :--- |
| `id` | VARCHAR(50) | PRIMARY KEY | Mã thợ (vd: `alex-tran`, `minh-anh`) |
| `name` | VARCHAR(255) | NOT NULL, UNIQUE | Họ và tên thợ cắt tóc |
| `role` | VARCHAR(100) | NULL | Chức danh chuyên môn (Master Stylist, Senior Hair Artist, Junior) |
| `level` | VARCHAR(50) | DEFAULT 'Senior' | Cấp bậc phục vụ tính hoa hồng ma trận (`Master`, `Senior`, `Junior`) |
| `baseSalary` | INT | DEFAULT 8000000 | Lương cứng cơ bản hàng tháng (VND) |
| `rating` | FLOAT | DEFAULT 5.0 | Điểm đánh giá trung bình từ khách hàng |
| `isAny` | INT | DEFAULT 0 | Đánh dấu thợ linh hoạt (`1`: Bất kỳ thợ nào, `0`: Thợ cụ thể) |

#### 3.4.3 Entity `appointments` (Đơn đặt lịch hẹn)
| Tên Trường (Field) | Kiểu dữ liệu | Ràng buộc | Mô tả giải thích |
| :--- | :--- | :--- | :--- |
| `id` | VARCHAR(50) | PRIMARY KEY | Mã đơn đặt lịch (vd: `LUMI-8921`) |
| `customerName` | VARCHAR(255) | NOT NULL | Tên khách hàng đặt lịch |
| `phone` | VARCHAR(50) | FOREIGN KEY (users.phone) | Số điện thoại liên hệ của khách hàng |
| `services` | TEXT | NULL | Mảng JSON danh sách dịch vụ chọn |
| `stylist` | VARCHAR(255) | FOREIGN KEY (stylists.name) | Tên thợ phụ trách phục vụ |
| `date` | VARCHAR(50) | NULL | Ngày hẹn (`Hôm nay` hoặc `DD/MM/YYYY`) |
| `time` | VARCHAR(50) | NULL | Khung giờ hẹn (`HH:MM`) |
| `totalPrice` | INT | DEFAULT 0 | Tổng chi phí dịch vụ (VND) |
| `depositAmount` | INT | DEFAULT 0 | Số tiền đặt cọc giữ chỗ 20% (VND) |
| `depositStatus` | VARCHAR(50) | DEFAULT 'Paid' | Trạng thái cọc (`Paid`, `Refunded`, `Forfeited`) |
| `status` | VARCHAR(50) | DEFAULT 'Pending' | Trạng thái ca hẹn (`Pending`, `Confirmed`, `InProgress`, `Completed`, `Cancelled`) |

#### 3.4.4 Entity `users` (Người dùng & Khách hàng)
| Tên Trường (Field) | Kiểu dữ liệu | Ràng buộc | Mô tả giải thích |
| :--- | :--- | :--- | :--- |
| `id` | INT | AUTO_INCREMENT, PK | Mã người dùng tự động |
| `name` | VARCHAR(255) | NOT NULL | Họ và tên người dùng |
| `phone` | VARCHAR(50) | NOT NULL, UNIQUE | Số điện thoại dùng làm khóa chính tham chiếu |
| `password` | VARCHAR(255) | NOT NULL | Mật khẩu tài khoản mã hóa |
| `role` | VARCHAR(20) | DEFAULT 'customer' | Vai trò hệ thống (`customer`, `admin`) |

#### 3.4.5 Entity `chat_messages` (Tin nhắn Live Chat)
| Tên Trường (Field) | Kiểu dữ liệu | Ràng buộc | Mô tả giải thích |
| :--- | :--- | :--- | :--- |
| `id` | INT | AUTO_INCREMENT, PK | Mã tin nhắn |
| `customer_phone` | VARCHAR(50) | FOREIGN KEY (users.phone) | Số điện thoại khách hàng tham gia chat |
| `sender` | ENUM | 'customer', 'admin' | Người gửi tin nhắn |
| `message` | TEXT | NOT NULL | Nội dung tin nhắn trò chuyện |
| `is_read` | TINYINT(1) | DEFAULT 0 | Đánh dấu trạng thái đã đọc (`1`: Đã đọc, `0`: Chưa đọc) |

#### 3.4.6 Entity `notification_logs` (Nhật ký thông báo)
| Tên Trường (Field) | Kiểu dữ liệu | Ràng buộc | Mô tả giải thích |
| :--- | :--- | :--- | :--- |
| `id` | INT | AUTO_INCREMENT, PK | Mã log thông báo |
| `appointment_id` | VARCHAR(50) | FOREIGN KEY (appointments.id) | Mã ca hẹn bị chuyển ca khẩn cấp |
| `channel` | VARCHAR(20) | NOT NULL | Kênh gửi thông báo (`SMS`, `Email`, `Both`) |
| `message` | TEXT | NOT NULL | Nội dung mẫu tin nhắn đã gửi tự động |
| `sent_at` | DATETIME | DEFAULT CURRENT_TIMESTAMP | Thời điểm gửi thông báo thành công |

---

## 4. EXTERNAL INTERFACE REQUIREMENTS (YÊU CẦU GIAO DIỆN BÊN NGOÀI)

### 4.1 User Interfaces (Giao diện người dùng)
- **Thiết kế Responsive UI**: Hoạt động tối ưu trên mọi màn hình từ Smartphone (375px) đến màn hình 4K Desktop.
- **Phong cách thẩm mỹ**: Gam màu chủ đạo Pastel Salon (`#FBF9F5` Nền kem, `#4A6B5D` Xanh rêu cao cấp, `#C89F82` Vàng đồng điểm nhấn).
- **Hệ thống Modal Interactive**: Modal đặt lịch 5 bước, Modal xem chi tiết bảng kê lương, Modal xử lý chuyển ca khẩn cấp.

### 4.2 Hardware Interfaces (Giao diện phần cứng)
- Tương thích thiết bị máy in nhiệt / máy in văn phòng tiêu chuẩn cho tính năng in phiếu lương và hóa đơn dịch vụ.

### 4.3 Software Interfaces (Giao diện phần mềm)
- **Hệ quản trị CSDL**: MySQL 8.0 / phpMyAdmin PDO Driver.
- **Thư viện FE**: Tailwind CSS CDN, Font Awesome Icons, Google Fonts (Playfair Display & Inter).

### 4.4 Communications Interfaces (Giao diện truyền thông)
- Tự động mã hóa cổng HTTP/HTTPS cho tất cả các giao dịch AJAX API.
- Chuẩn giao tiếp dữ liệu trao đổi: `application/json; charset=utf-8`.

---

## 5. TECHNICAL REQUIREMENTS (NON FUNCTIONAL) (YÊU CẦU KỸ THUẬT PHI CHỨC NĂNG)

### 5.1 Performance (Hiệu năng)
- Thời gian phản hồi trang web $< 0.5$ giây.
- Thời gian tính toán ma trận hoa hồng và xuất báo cáo lương tháng $< 0.2$ giây cho 10.000 ca hẹn.
- Thuật toán Anti Double-Booking quét khung giờ trống bằng truy vấn PDO trong $< 50$ms.

### 5.2 Scalability (Khả năng mở rộng)
- Kiến trúc CSDL đáp ứng tốt hơn 100.000 lịch hẹn và 500 thợ salon đồng thời.
- Sẵn sàng tích hợp cổng thanh toán trực tuyến (VNPay / MoMo / ZaloPay).

### 5.3 Security (Bảo mật)
- Mã hóa mật khẩu người dùng với thuật toán an toàn.
- Phòng chống lỗ hổng SQL Injection bằng 100% PDO Prepared Statements.
- Chống tấn công XSS bằng hàm lọc `htmlspecialchars()`.
- Kiểm soát phân quyền Session riêng biệt giữa Admin (`$_SESSION['admin']`) và Stylist (`$_SESSION['stylist']`).

### 5.4 Maintainability (Khả năng bảo trì)
- Cấu trúc thư mục mô-đun hóa sạch (Separation of Concerns): `db.php` (kết nối CSDL & helpers), `admin_nav.php` (sidebar chung), `api.php` (API backend).
- Mã nguồn viết tiếng Việt có chú thích từng hàm xử lý.

### 5.5 Usability (Tính dễ sử dụng)
- Giao diện trải nghiệm UX mượt mà, khách hàng không cần qua các bước đăng ký phức tạp vẫn có thể hoàn tất đặt lịch trong 60 giây.

### 5.6 Multi-lingual Support (Hỗ trợ đa ngôn ngữ)
- Ngôn ngữ hiển thị chính: Tiếng Việt chuẩn Salon (Chờ xác nhận, Đã xác nhận, Đang thực hiện, Đã hoàn thành, Đã hủy).

### 5.7 Auditing and Logging (Kiểm toán & Ghi log)
- Lưu nhật ký chi tiết tất cả thông báo gửi cho khách hàng khi thợ nghỉ đột xuất trong bảng `notification_logs`.

### 5.8 Availability (Độ khả dụng)
- Độ sẵn sàng hệ thống đạt 99.9% Uptime, đảm bảo tiếp nhận lịch hẹn 24/7.

---

## 6. OPEN ISSUES (VẤN ĐỀ MỞ & PHÁT TRIỂN TƯƠNG LAI)

1. Tích hợp Webhook kết nối trực tiếp với tổng đài SMS Brandname thực tế và dịch vụ gửi Email SMTP tự động.
2. Phát triển ứng dụng di động (Mobile App Client) trên iOS / Android sử dụng React Native đồng bộ với cơ sở dữ liệu hiện tại.
