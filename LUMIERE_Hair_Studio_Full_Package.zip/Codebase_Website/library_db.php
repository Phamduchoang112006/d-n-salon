<?php
// ============================================================
// HỆ THỐNG QUẢN LÝ THƯ VIỆN & TIỆM THUÊ TRUYỆN ENTERPRISE 5.0
// Database Connection & Full Content Seeder Module (25+ Đầu Sách & Truyện)
// Nhóm: Nguyễn Đăng Khải (Leader), Nguyễn Nhật Linh Ân, Phan Duy
// ============================================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('LIB_DB_TYPE', 'mysql');
define('LIB_MYSQL_HOST', '127.0.0.1');
define('LIB_MYSQL_PORT', '3306');
define('LIB_MYSQL_DB', 'thuvien_db');
define('LIB_MYSQL_USER', 'root');
define('LIB_MYSQL_PASS', '');

define('LIB_SQLITE_FILE', __DIR__ . '/data/library_enterprise_v5.sqlite');

function get_lib_pdo() {
    static $pdo = null;
    if ($pdo !== null) return $pdo;

    if (LIB_DB_TYPE === 'mysql') {
        try {
            $dsn = 'mysql:host=' . LIB_MYSQL_HOST . ';port=' . LIB_MYSQL_PORT . ';dbname=' . LIB_MYSQL_DB . ';charset=utf8mb4';
            $pdo = new PDO($dsn, LIB_MYSQL_USER, LIB_MYSQL_PASS);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            return $pdo;
        } catch (PDOException $e) {
            // SQLite Fallback
        }
    }

    $dir = dirname(LIB_SQLITE_FILE);
    if (!is_dir($dir)) mkdir($dir, 0777, true);
    $need_init = !file_exists(LIB_SQLITE_FILE);

    $pdo = new PDO('sqlite:' . LIB_SQLITE_FILE);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

    init_sqlite_enterprise_tables($pdo);
    return $pdo;
}

function init_sqlite_enterprise_tables($pdo) {
    $queries = [
        "CREATE TABLE IF NOT EXISTS admins (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            password_hash TEXT,
            full_name TEXT,
            email TEXT,
            role TEXT DEFAULT 'Quản trị viên',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );",
        "CREATE TABLE IF NOT EXISTS categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ma_danh_muc TEXT UNIQUE,
            ten_danh_muc TEXT,
            mo_ta TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );",
        "CREATE TABLE IF NOT EXISTS books (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ma_sach TEXT UNIQUE,
            ten_sach TEXT,
            tac_gia TEXT,
            category_id INTEGER,
            nha_xuat_ban TEXT,
            nam_xuat_ban INTEGER,
            gia_bia REAL DEFAULT 50000.00,
            ty_le_coc INTEGER DEFAULT 80,
            gia_thue_ngay REAL DEFAULT 3000.00,
            hinh_thuc TEXT DEFAULT 'Thuê lẻ',
            so_luong INTEGER DEFAULT 10,
            co_san INTEGER DEFAULT 8,
            hinh_anh TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );",
        "CREATE TABLE IF NOT EXISTS physical_copies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            book_id INTEGER,
            barcode TEXT UNIQUE,
            tu_ke_kho TEXT DEFAULT 'Kệ A1-Tủ 01',
            tinh_trang_hao_mon TEXT DEFAULT 'Mới 99%',
            so_lan_thue INTEGER DEFAULT 0,
            trang_thai TEXT DEFAULT 'Có sẵn',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );",
        "CREATE TABLE IF NOT EXISTS readers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ma_doc_gia TEXT UNIQUE,
            ho_ten TEXT,
            email TEXT UNIQUE,
            so_dien_thoai TEXT,
            mat_khau_hash TEXT DEFAULT '123456',
            dia_chi TEXT,
            so_du_vi REAL DEFAULT 500000.00,
            tien_coc_dong_bang REAL DEFAULT 0.00,
            xac_minh_kyc TEXT DEFAULT 'Đã xác minh eKYC',
            loai_doc_gia TEXT DEFAULT 'Thường',
            trang_thai TEXT DEFAULT 'Hoạt động',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );",
        "CREATE TABLE IF NOT EXISTS rental_orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ma_don TEXT UNIQUE,
            reader_id INTEGER,
            ngay_bat_dau DATE,
            ngay_ket_thuc DATE,
            ngay_tra_thuc_te DATE,
            phuong_thuc_nhan TEXT DEFAULT 'Giao tận nơi',
            tong_tien_thue REAL DEFAULT 0.00,
            tong_tien_coc REAL DEFAULT 0.00,
            tien_coc_da_hoan REAL DEFAULT 0.00,
            tien_phat REAL DEFAULT 0.00,
            so_lan_gia_han INTEGER DEFAULT 0,
            trang_thai TEXT DEFAULT 'Đang mượn',
            ghi_chu TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );",
        "CREATE TABLE IF NOT EXISTS rental_order_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER,
            physical_copy_id INTEGER,
            tien_coc_item REAL,
            tien_thue_item REAL,
            tinh_trang_khi_tra TEXT DEFAULT 'Chưa trả'
        );",
        "CREATE TABLE IF NOT EXISTS wallet_transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            reader_id INTEGER,
            ma_giao_dich TEXT UNIQUE,
            loai_giao_dich TEXT,
            so_tien REAL,
            mo_ta TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );",
        "CREATE TABLE IF NOT EXISTS inventory_locks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            physical_copy_id INTEGER UNIQUE,
            reader_id INTEGER,
            expires_at DATETIME,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );",
        "CREATE TABLE IF NOT EXISTS manga_services (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            freelancer_name TEXT,
            freelancer_avatar TEXT,
            freelancer_badge TEXT DEFAULT 'Top Rated',
            rating_score REAL DEFAULT 4.9,
            review_count INTEGER DEFAULT 85,
            title TEXT,
            category_tag TEXT DEFAULT 'Vẽ Manga',
            portfolio_image TEXT,
            delivery_days INTEGER DEFAULT 2,
            starting_price REAL DEFAULT 150000.00,
            price_basic REAL DEFAULT 150000.00,
            price_standard REAL DEFAULT 350000.00,
            price_premium REAL DEFAULT 800000.00,
            description TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );",
        "CREATE TABLE IF NOT EXISTS manga_service_orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ma_don_ve TEXT UNIQUE,
            reader_id INTEGER,
            service_id INTEGER,
            package_tier TEXT DEFAULT 'Gói Tiêu Chuẩn',
            so_tien REAL,
            yeu_cau_chi_tiet TEXT,
            trang_thai TEXT DEFAULT 'Đang thực hiện',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );"
    ];

    foreach ($queries as $q) {
        $pdo->exec($q);
    }

    // Seed Admins
    if ($pdo->query("SELECT COUNT(*) FROM admins")->fetchColumn() == 0) {
        $pdo->exec("INSERT INTO admins (username, password_hash, full_name, email, role) VALUES
            ('admin', '123456', 'Nguyễn Đăng Khải', 'admin@thuvien.edu.vn', 'Quản trị viên'),
            ('thuthu', '123456', 'Nguyễn Nhật Linh Ân', 'thuthu@thuvien.edu.vn', 'Thủ thư');");
    }

    // Seed Categories
    if ($pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn() == 0) {
        $pdo->exec("INSERT INTO categories (ma_danh_muc, ten_danh_muc, mo_ta) VALUES
            ('DM01', 'Truyện Tranh & Manga', 'Truyện tranh Nhật Bản, Manga, Comic kinh điển'),
            ('DM02', 'Tiểu Thuyết & Trinh Thám', 'Harry Potter, Sherlock Holmes, Nguyễn Nhật Ánh'),
            ('DM03', 'Công Nghệ & Lập Trình', 'Clean Code, ReactJS, PHP MySQL, Data Structure'),
            ('DM04', 'Sách Kỹ Năng & Kinh Tế', 'Cha Giàu Cha Nghèo, Đắc Nhân Tâm, Hạt Giống Tâm Hồn');");
    }

    // Seed 20+ Rich Books & Manga
    if ($pdo->query("SELECT COUNT(*) FROM books")->fetchColumn() == 0) {
        $pdo->exec("INSERT INTO books (ma_sach, ten_sach, tac_gia, category_id, nha_xuat_ban, nam_xuat_ban, gia_bia, ty_le_coc, gia_thue_ngay, hinh_thuc, so_luong, co_san, hinh_anh) VALUES
            ('TT001', 'Doraemon - Tập 1: Chú Mèo Máy Đến Từ Tương Lai', 'Fujiko F. Fujio', 1, 'NXB Kim Đồng', 2023, 25000.00, 80, 2000.00, 'Thuê lẻ', 15, 12, 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=400'),
            ('TT002', 'Thám Tử Lừng Danh Conan - Tập 100', 'Gosho Aoyama', 1, 'NXB Kim Đồng', 2023, 30000.00, 80, 3000.00, 'Thuê lẻ', 20, 16, 'https://images.unsplash.com/photo-1618663938039-b33024897776?w=400'),
            ('TT003', 'Dragon Ball - Bảy Viên Ngọc Rồng Tập 1', 'Akira Toriyama', 1, 'NXB Kim Đồng', 2022, 28000.00, 80, 2500.00, 'Combo bộ', 12, 9, 'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=400'),
            ('TT004', 'One Piece - Đảo Hải Tặc Tập 101', 'Eiichiro Oda', 1, 'NXB Kim Đồng', 2023, 32000.00, 80, 3000.00, 'Combo bộ', 18, 14, 'https://images.unsplash.com/photo-1563089145-599997674d42?w=400'),
            ('TT005', 'Naruto - Huyền Thoại Làng Lá Tập 1', 'Masashi Kishimoto', 1, 'NXB Kim Đồng', 2021, 25000.00, 80, 2500.00, 'Thuê lẻ', 10, 8, 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=400'),
            ('TT006', 'Jujutsu Kaisen - Chú Thuật Hồi Chiến Tập 1', 'Gege Akutami', 1, 'NXB Kim Đồng', 2023, 35000.00, 80, 3500.00, 'Thuê lẻ', 12, 10, 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=400'),
            ('TT007', 'Demon Slayer - Thanh Gươm Diệt Quỷ Tập 1', 'Koyoharu Gotouge', 1, 'NXB Kim Đồng', 2022, 30000.00, 80, 3000.00, 'Thuê lẻ', 14, 11, 'https://images.unsplash.com/photo-1618663938039-b33024897776?w=400'),
            ('TT008', 'Spy x Family - Gia Đình Điệp Viên Tập 1', 'Tatsuya Endo', 1, 'NXB Kim Đồng', 2023, 35000.00, 80, 3500.00, 'Thuê lẻ', 10, 9, 'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=400'),

            ('NO001', 'Harry Potter Và Hòn Đá Phù Thủy', 'J.K. Rowling', 2, 'NXB Trẻ', 2021, 150000.00, 80, 6000.00, 'Thuê lẻ', 10, 8, 'https://images.unsplash.com/photo-1626618012641-bfbca5a31239?w=400'),
            ('NO002', 'Sherlock Holmes - Cậu Bé Trinh Thám', 'Arthur Conan Doyle', 2, 'NXB Văn Học', 2021, 120000.00, 80, 5000.00, 'Thuê lẻ', 8, 6, 'https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=400'),
            ('NO003', 'Mắt Biếc', 'Nguyễn Nhật Ánh', 2, 'NXB Trẻ', 2020, 110000.00, 80, 4500.00, 'Thuê lẻ', 12, 10, 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400'),
            ('NO004', 'Tôi Thấy Hoa Vàng Trên Cỏ Xanh', 'Nguyễn Nhật Ánh', 2, 'NXB Trẻ', 2022, 125000.00, 80, 5000.00, 'Thuê lẻ', 15, 13, 'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400'),
            ('NO005', 'Nhà Giả Kim', 'Paulo Coelho', 2, 'NXB Hội Nhà Văn', 2021, 95000.00, 80, 4000.00, 'Thuê lẻ', 16, 14, 'https://images.unsplash.com/photo-1476275466078-4007374efbbe?w=400'),

            ('MS001', 'Clean Code: Mã Sạch & Nghệ Thuật Lập Trình', 'Robert C. Martin', 3, 'Prentice Hall', 2020, 220000.00, 80, 8000.00, 'Thuê lẻ', 10, 8, 'https://images.unsplash.com/photo-1532012197267-da84d127e765?w=400'),
            ('MS002', 'Lập Trình Web Với ReactJS & Node.js', 'Nguyễn Văn A', 3, 'NXB Thống Kê', 2023, 180000.00, 80, 7000.00, 'Thuê lẻ', 12, 10, 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=400'),
            ('MS003', 'Lập Trình PHP & MySQL Chuyên Nghiệp', 'Trần Thị B', 3, 'NXB Lao Động', 2022, 160000.00, 80, 6000.00, 'Thuê lẻ', 10, 8, 'https://images.unsplash.com/photo-1599507593499-a3f7d7d97667?w=400'),
            ('MS004', 'The Pragmatic Programmer', 'Andrew Hunt', 3, 'Addison-Wesley', 2021, 250000.00, 80, 9000.00, 'Thuê lẻ', 8, 6, 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400'),

            ('SK001', 'Đắc Nhân Tâm', 'Dale Carnegie', 4, 'NXB Tổng Hợp TPHCM', 2021, 98000.00, 80, 4000.00, 'Thuê lẻ', 20, 16, 'https://images.unsplash.com/photo-1589829085413-56de8ae18c73?w=400'),
            ('SK002', 'Cha Giàu Cha Nghèo', 'Robert Kiyosaki', 4, 'NXB Trẻ', 2022, 135000.00, 80, 5000.00, 'Thuê lẻ', 15, 12, 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400'),
            ('SK003', 'Tuổi Trẻ Đáng Giá Bao Nhiêu?', 'Rosie Nguyễn', 4, 'NXB Hội Nhà Văn', 2022, 115000.00, 80, 4500.00, 'Thuê lẻ', 18, 15, 'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400');");
    }

    // Seed Manga Freelancer Services (Fastlance Style)
    if ($pdo->query("SELECT COUNT(*) FROM manga_services")->fetchColumn() == 0) {
        $pdo->exec("INSERT INTO manga_services (freelancer_name, freelancer_avatar, freelancer_badge, rating_score, review_count, title, category_tag, portfolio_image, delivery_days, starting_price, price_basic, price_standard, price_premium, description) VALUES
            ('KuroNeko Studio', 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150', 'Top Rated Seller', 5.0, 142, 'Vẽ Truyện Tranh Manga & Webtoon Theo Yêu Cầu Phong Cách Chuẩn Nhật Bản', 'Vẽ Manga', 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=600', 3, 200000.00, 200000.00, 450000.00, 950000.00, 'Nhận thiết kế trang truyện tranh Manga kịch bản có sẵn. Đảm bảo góc quay sinh động, đổ bóng chi tiết, xuất file 300DPI in ấn.'),
            ('Họa Sĩ Linh Ân', 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150', 'Verified Pro', 4.9, 98, 'Thiết Kế Nhân Vật Anime / Chibi 2D Chuyên Nghiệp Cho Webtoon & Game', 'Vẽ Anime/Chibi', 'https://images.unsplash.com/photo-1618663938039-b33024897776?w=600', 2, 150000.00, 150000.00, 300000.00, 650000.00, 'Tạo hình nhân vật độc quyền kèm 3 biểu cảm cảm xúc (Vui, Giận, Khóc). File vector hoặc PNG tách nền rõ nét.'),
            ('Phan Duy Manga Art', 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150', 'Fast Delivery', 4.8, 64, 'Vẽ Minh Họa Bìa Light Novel / Manga Độc Bản Màu Sắc Rực Rỡ', 'Minh Họa Bìa', 'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=600', 1, 350000.00, 350000.00, 600000.00, 1200000.00, 'Vẽ bìa sách, bìa truyện tranh 4K màu kỹ thuật số. Bao gồm thiết kế Typography tiêu đề nghệ thuật.'),
            ('Sakura Manga Team', 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=150', 'Top Rated Seller', 5.0, 210, 'Vẽ Lineart & Đổ Màu Manga Trọn Bộ Nhiều Trang Theo Yêu Cầu', 'Vẽ Manga', 'https://images.unsplash.com/photo-1563089145-599997674d42?w=600', 4, 180000.00, 180000.00, 400000.00, 850000.00, 'Chuyên lineart sắc nét và tô màu phong cách Shonen/Shojo. Miễn phí chỉnh sửa 3 lần.'),
            ('Đăng Khải Comic', 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150', 'Verified Pro', 4.9, 115, 'Chuyển Thể Kịch Bản Văn Học Thành Comic / Webtoon Màu Sắc Hiện Đại', 'Vẽ Webtoon', 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=600', 3, 250000.00, 250000.00, 500000.00, 1100000.00, 'Biến câu chuyện văn học thành từng khung hình webtoon cuộn dọc tối ưu đọc trên điện thoại thông minh.');");
    }

    // Seed Physical Copies
    if ($pdo->query("SELECT COUNT(*) FROM physical_copies")->fetchColumn() == 0) {
        $pdo->exec("INSERT INTO physical_copies (book_id, barcode, tu_ke_kho, tinh_trang_hao_mon, so_lan_thue, trang_thai) VALUES
            (1, 'BC-DORA-001', 'Kệ Manga-A1', 'Mới 99%', 2, 'Có sẵn'),
            (1, 'BC-DORA-002', 'Kệ Manga-A1', 'Khá', 8, 'Có sẵn'),
            (2, 'BC-CONAN-001', 'Kệ Manga-A2', 'Mới 99%', 1, 'Đang cho thuê'),
            (3, 'BC-DRAGON-001', 'Kệ Manga-A3', 'Mới 99%', 4, 'Có sẵn'),
            (4, 'BC-ONEPIECE-001', 'Kệ Manga-A4', 'Mới 99%', 5, 'Có sẵn'),
            (9, 'BC-HARRY-001', 'Kệ Novel-B1', 'Mới 99%', 3, 'Có sẵn'),
            (14, 'BC-CLEAN-001', 'Kệ CNTT-C1', 'Mới 99%', 0, 'Có sẵn');");
    }

    // Seed Readers
    if ($pdo->query("SELECT COUNT(*) FROM readers")->fetchColumn() == 0) {
        $pdo->exec("INSERT INTO readers (ma_doc_gia, ho_ten, email, so_dien_thoai, mat_khau_hash, dia_chi, so_du_vi, tien_coc_dong_bang, loai_doc_gia) VALUES
            ('DG001', 'Nguyễn Đăng Khải', 'khainguyen@gmail.com', '0905123456', '123456', 'Đà Nẵng', 850000.00, 24000.00, 'VIP Gold'),
            ('DG002', 'Nguyễn Nhật Linh Ân', 'anlinh@gmail.com', '0905234567', '123456', 'Đà Nẵng', 500000.00, 0.00, 'Sinh viên'),
            ('DG003', 'Phan Duy', 'duyphan@gmail.com', '0905345678', '123456', 'Đà Nẵng', 450000.00, 0.00, 'Sinh viên');");
    }

    if ($pdo->query("SELECT COUNT(*) FROM rental_orders")->fetchColumn() == 0) {
        $pdo->exec("INSERT INTO rental_orders (ma_don, reader_id, ngay_bat_dau, ngay_ket_thuc, tong_tien_thue, tong_tien_coc, trang_thai) VALUES
            ('RENT-8801', 1, '2026-09-01', '2026-09-15', 42000.00, 24000.00, 'Đang mượn');");
    }

    if ($pdo->query("SELECT COUNT(*) FROM wallet_transactions")->fetchColumn() == 0) {
        $pdo->exec("INSERT INTO wallet_transactions (reader_id, ma_giao_dich, loai_giao_dich, so_tien, mo_ta) VALUES
            (1, 'WT-1001', 'Nạp tiền', 1000000.00, 'Nạp tiền qua VietQR'),
            (1, 'WT-1002', 'Đóng băng cọc', 24000.00, 'Đóng băng tiền cọc đơn RENT-8801');");
    }
}

function lib_response($status, $message = '', $data = []) {
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
    echo json_encode(array_merge([
        'status' => $status,
        'message' => $message,
        'data' => $data
    ]), JSON_UNESCAPED_UNICODE);
    exit;
}

